//PagoT = pago tarjeta

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import com.mysql.cj.jdbc.ConnectionImpl;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class pagoT extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	static JTextField tarjetaTF = new JTextField();
	private JTextField cvvTF;
	static String tarjetaUser;
	
	MySqlConn con = new MySqlConn();
	Connection cn=con.conexion();
	

private fichasP fp;
public void setPagoT(pagoT pt) {
}
public void setmain(main m) {
}
public void setFichasP(fichasP fp) {
	this.fp = fp;
}
private void regresarBtn(java.awt.event.ActionEvent avt) {
	fp.setVisible(true);
	this.setVisible(false);
}
private void continuarBtn(java.awt.event.ActionEvent avt) {
	main.pagado=true;
	main.main(null);
	this.setVisible(false);


}
	
	/**
	* Create the frame.
	
	*/

public pagoT() {
	
	
	super();
	setResizable(false);
	setTitle("Casino KaS");
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setSize(500, 400);
	setLocationRelativeTo(null);
	contentPane = new JPanel();
	contentPane.setBackground(new Color(0, 128, 64));
	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	
	setContentPane(contentPane);
	contentPane.setLayout(null);
	
	JButton btnNewButton = new JButton("Regresar");
	btnNewButton.setBounds(10, 327, 89, 23);
	btnNewButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			regresarBtn(e);
		}
	});
	btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
	contentPane.add(btnNewButton);
	
	JLabel lblPagoConTarjeta = new JLabel("Pago con tarjeta");
	lblPagoConTarjeta.setHorizontalAlignment(SwingConstants.LEFT);
	lblPagoConTarjeta.setForeground(Color.WHITE);
	lblPagoConTarjeta.setFont(new Font("Calisto MT", Font.BOLD, 25));
	lblPagoConTarjeta.setBounds(153, 11, 195, 30);
	contentPane.add(lblPagoConTarjeta);
	
	JLabel lblNumDeTarjeta = new JLabel("Num. de tarjeta:");
	lblNumDeTarjeta.setHorizontalAlignment(SwingConstants.LEFT);
	lblNumDeTarjeta.setForeground(Color.WHITE);
	lblNumDeTarjeta.setFont(new Font("Calisto MT", Font.BOLD, 18));
	lblNumDeTarjeta.setBounds(10, 120, 145, 30);
	contentPane.add(lblNumDeTarjeta);
	
	JLabel lblTarjeta = new JLabel("Tarjeta");
	lblTarjeta.setHorizontalAlignment(SwingConstants.LEFT);
	lblTarjeta.setForeground(Color.WHITE);
	lblTarjeta.setFont(new Font("Calisto MT", Font.BOLD, 18));
	lblTarjeta.setBounds(10, 79, 145, 30);
	contentPane.add(lblTarjeta);
	
	JRadioButton rdbtnMasterCard = new JRadioButton("Mastercard");
	rdbtnMasterCard.setFont(new Font("Tahoma", Font.PLAIN, 13));
	rdbtnMasterCard.setForeground(new Color(255, 255, 255));
	rdbtnMasterCard.setBackground(new Color(0, 128, 64));
	rdbtnMasterCard.setBounds(143, 82, 109, 23);
	contentPane.add(rdbtnMasterCard);
	
	JLabel lblTotalAPagar = new JLabel("Total a pagar: "+main.pago);
	lblTotalAPagar.setHorizontalAlignment(SwingConstants.LEFT);
	lblTotalAPagar.setForeground(Color.WHITE);
	lblTotalAPagar.setFont(new Font("Calisto MT", Font.BOLD, 25));
	lblTotalAPagar.setBounds(153, 38, 255, 30);

	contentPane.add(lblTotalAPagar);
	
	tarjetaTF.setHorizontalAlignment(SwingConstants.LEFT);
	tarjetaTF.addKeyListener(new KeyAdapter() {
		public void keyTyped(KeyEvent e) {
			int caracter = e.getKeyChar();
			
			// Verificar si la tecla pulsada no es un digito
			if((caracter < '0') ||(caracter > '9') && (caracter !='\b')) {
				e.consume(); // ignorar el evento de teclado
			}
			if(tarjetaTF.getText().length()>15) {
				e.consume();
			}
		}
	});
	if(login.loged&&!login.tarj.equals("")) {
		tarjetaTF.setText(login.tarj);
		tarjetaTF.setForeground(Color.BLACK);
	} else {
		tarjetaTF.setText("Num Tarjeta (16 digts)");
		tarjetaTF.setForeground(Color.GRAY);
	}
	tarjetaTF.addFocusListener(new FocusListener() {
		@Override
		public void focusGained(FocusEvent e) {
			if (tarjetaTF.getText().equals("Num Tarjeta (16 digts)")) {
				tarjetaTF.setText("");
				tarjetaTF.setForeground(Color.BLACK);
				tarjetaTF.setHorizontalAlignment(SwingConstants.LEFT);
			}
		}
		@Override
		public void focusLost(FocusEvent e) {
			if (tarjetaTF.getText().isEmpty()) {
				tarjetaTF.setForeground(Color.GRAY);
				tarjetaTF.setText("Num Tarjeta (16 digts)");
				tarjetaTF.setHorizontalAlignment(SwingConstants.LEFT);
			}
		}
	});
	tarjetaTF.setFont(new Font("Tahoma", Font.PLAIN, 16));
	tarjetaTF.setBounds(153, 124, 183, 26);
	contentPane.add(tarjetaTF);
	tarjetaTF.setColumns(10);
	
	JLabel lblCvv = new JLabel("CVV");
	lblCvv.setHorizontalAlignment(SwingConstants.LEFT);
	lblCvv.setForeground(Color.WHITE);
	lblCvv.setFont(new Font("Calisto MT", Font.BOLD, 18));
	lblCvv.setBounds(10, 161, 50, 30);
	contentPane.add(lblCvv);
	
	JLabel lblFechaDeCaduciad = new JLabel("Fecha de caducidad");
	lblFechaDeCaduciad.setHorizontalAlignment(SwingConstants.LEFT);
	lblFechaDeCaduciad.setForeground(Color.WHITE);
	lblFechaDeCaduciad.setFont(new Font("Calisto MT", Font.BOLD, 18));
	lblFechaDeCaduciad.setBounds(10, 202, 173, 30);
	contentPane.add(lblFechaDeCaduciad);
	
	cvvTF = new JTextField();
	cvvTF.setHorizontalAlignment(SwingConstants.LEFT);
	cvvTF.setForeground(Color.GRAY);
	cvvTF.setFont(new Font("Tahoma", Font.PLAIN, 16));
	cvvTF.setColumns(10);
	cvvTF.setBounds(153, 161, 76, 26);
	contentPane.add(cvvTF);
	cvvTF.addKeyListener(new KeyAdapter() {
		public void keyTyped(KeyEvent e) {
			int caracter = e.getKeyChar();
			// Verificar si la tecla pulsada no es un digito
			if((caracter < '0') ||(caracter > '9') &&(caracter != '\b')) {
				e.consume(); // ignorar el evento de teclado
			}
			if(cvvTF.getText().length()>2) {
				e.consume();
			}
		}
	});
	
	cvvTF.setText("Ej. 123");
	cvvTF.setForeground(Color.GRAY);
	cvvTF.addFocusListener(new FocusListener() {
		@Override
		public void focusGained(FocusEvent e) {
			if (cvvTF.getText().equals("Ej. 123")) {
				cvvTF.setText("");
				cvvTF.setForeground(Color.BLACK);
				tarjetaTF.setHorizontalAlignment(SwingConstants.LEFT);
			}
		}
		@Override
		public void focusLost(FocusEvent e) {
			if (cvvTF.getText().isEmpty()) {
				cvvTF.setForeground(Color.GRAY);
				cvvTF.setText("Ej. 123");
				tarjetaTF.setHorizontalAlignment(SwingConstants.LEFT);
			}
		}
	});
		JComboBox fcAnoCmbx = new JComboBox();
	JComboBox fcMesCmbx = new JComboBox();
	fcMesCmbx.setOpaque(true);
	fcMesCmbx.setFocusable(false);
	fcMesCmbx.setForeground(new Color(0, 0, 0));
	fcMesCmbx.setFont(new Font("Tahoma", Font.PLAIN, 17));
	fcMesCmbx.setModel(new DefaultComboBoxModel(new String[] {"Mes", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Octubre", "Noviembre", "Diciembre"}));
	fcMesCmbx.setBounds(20, 242, 100, 21);
	contentPane.add(fcMesCmbx);

	fcAnoCmbx.setOpaque(true);
	fcAnoCmbx.setFocusable(false);
	fcAnoCmbx.setForeground(new Color(0, 0, 0));
	fcAnoCmbx.setFont(new Font("Tahoma", Font.PLAIN, 17));
	fcAnoCmbx.setModel(new DefaultComboBoxModel(new String[] {"Año", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032"}));
	fcAnoCmbx.setBounds(130, 242, 76, 21);
	contentPane.add(fcAnoCmbx);
	
	JButton btnContinuar = new JButton("Continuar");
	btnContinuar.setEnabled(false);
	btnContinuar.setBounds(385, 327, 89, 23);
	btnContinuar.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(tarjetaTF.getText().equals("")||tarjetaTF.getText().equals("Num Tarjeta (16 digts)") ||tarjetaTF.getText().length()<16||cvvTF.getText().equals("")||cvvTF.getText().equals("Ej. 123") ||cvvTF.getText().length()<3) {
				JOptionPane.showMessageDialog(null,"Numero de tarjeta o CVV invalidos","Error",JOptionPane.ERROR_MESSAGE);
			} else if(fcAnoCmbx.getSelectedIndex()==0||fcMesCmbx.getSelectedIndex()==0) {
				JOptionPane.showMessageDialog(null,"Ingrese una fecha de vencimiento valida","Error",JOptionPane.ERROR_MESSAGE);
			}else {
				continuarBtn(e);
				String tarj = tarjetaTF.getText();
				//guardarDB(tarj, fichasM.cantidadF, main.pago);
				main.totalFichas+=fichasM.cantidadF;
				String URL = "jdbc:mysql://localhost:3306/registroskas_bd";
				String USER = "root";
				String PASSW = "";
				int fichasCompradas = 0;
				int totalComprado = 0;
				try (Connection conn = DriverManager.getConnection(URL, USER, PASSW)){
					String SQL = "update users set fichasT=?, tarjeta=?, fichas_compradas=?, total_comprado=? where user_n=?";
					String SQL1 = "SELECT * FROM users WHERE user_n=?";
					login.loged=true;
					PreparedStatement ps1 = conn.prepareStatement(SQL1);
					ps1.setString(1, login.user);
					ResultSet rs=ps1.executeQuery();
					if(rs.next()) {
						tarjetaUser = rs.getString("tarjeta");
						fichasCompradas = rs.getInt("fichas_compradas") + fichasM.cantidadF;
						totalComprado = rs.getInt("total_comprado") + main.pago;
					}
					PreparedStatement ps = conn.prepareStatement(SQL);
					ps.setInt(1, main.totalFichas);
					ps.setString(2, tarj);
					ps.setInt(3, fichasCompradas);
					ps.setInt(4, totalComprado);
					ps.setString(5, login.user);
					int resul = ps.executeUpdate();
					if(resul>0) {
						System.out.println("Conexion exitosa");
					} else {
						System.out.println("Conexion fallida");
					}
					conn.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		}
	});
	btnContinuar.setFont(new Font("Tahoma", Font.PLAIN, 13));
	contentPane.add(btnContinuar);
	

	
	
	int temp=main.pago;
	JRadioButton rdbtnVisa = new JRadioButton("Visa");
	rdbtnVisa.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(rdbtnMasterCard.isSelected() || rdbtnVisa.isSelected()) {
				btnContinuar.setEnabled(true);
			}
			while(temp==main.pago) {
				main.pago /=2;
				if(rdbtnVisa.isSelected()) {
					lblTotalAPagar.setText("Total a pagar: "+main.pago);
				}
			}
			
		}
	});
	rdbtnVisa.setFont(new Font("Tahoma", Font.PLAIN, 13));
	rdbtnVisa.setForeground(new Color(255, 255, 255));
	rdbtnVisa.setBackground(new Color(0, 128, 64));
	rdbtnVisa.setBounds(268, 82, 109, 23);
	contentPane.add(rdbtnVisa);

	
	rdbtnMasterCard.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(rdbtnMasterCard.isSelected() || rdbtnVisa.isSelected()) {
				btnContinuar.setEnabled(true);
			} if(rdbtnMasterCard.isSelected()) {
				if(temp!=main.pago) {
					main.pago*=2;
					lblTotalAPagar.setText("Total a pagar: "+main.pago);
				}
			}
		}
	});
	
	ButtonGroup g = new ButtonGroup();
	g.add(rdbtnVisa);
	g.add(rdbtnMasterCard);
}
//private void guardarDB(String tarjeta, int fichas, int total) {
//	String URL = "jdbc:mysql://localhost:3306/registroskas_bd";
//	String USER = "root";
//	String PASSW = "";
//	try (Connection conn = DriverManager.getConnection(URL, USER, PASSW)){
//		String SQL = "INSERT INTO users(tarjeta, fichas_compradas, total_comprado) VALUES(?,?,?) where user_n=?";
//		try(PreparedStatement stmt = conn.prepareStatement(SQL)) {
//			stmt.setString(1, tarjeta);
//			stmt.setInt(2, fichas);
//			stmt.setInt(3, total);
//			stmt.setString(4, login.user);
//			stmt.executeUpdate();
//		}
//		conn.close();
//	} catch(SQLException e) {
//		//JOptionPane.showMessageDialog(null, "Error inesperado "+e, "Error", JOptionPane.ERROR_MESSAGE);
//	}
//}
}