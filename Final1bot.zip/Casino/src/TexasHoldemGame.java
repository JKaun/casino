
import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.GroupLayout.Alignment;
import java.awt.event.MouseWheelListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class TexasHoldemGame extends JFrame{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	MySqlConn con = new MySqlConn();
	Connection cn=con.conexion();
	
	
	private JFrame frame;
	private JCheckBox sitOut;
	private JScrollPane sp;
	private JTextArea messageArea;
	private JPanel playersPanel, player1Panel, communityPanel, divPanel, actionPanel;
    private JLabel potLabel, turnLabel, player1Lbl, playerPosition;
    private List<Card> communityCards, player1Cards, player2Cards;
    private JButton raiseButton, playAgain, checkCallButton, foldButton, regresarBtn; // Botones de accion
    private boolean inGame, hasBet, player1Turn, player1Checked, player2Checked, folded1, folded2, player1InGame; // Indica si hay una apuesta en la mesa
    private int currentBet, pot, currentRound, playerCardWidth, playerCardHeight, communityCardWidth, communityCardHeight; // Apuesta actual, pot y ronda actual
	private JSpinner betSpinner;
    private int currentBlindPosition = 0; // 0 para jugador 1, 1 para jugador 2
    private int smallBlind = 500; // Ejemplo de ciega pequeña
    private int bigBlind = 1000; // Ejemplo de ciega grande
	TexasHoldemGame.Hand.HandEvaluation player1Evaluation, player2Evaluation;
    ArrayList<Card> deck;
    Random random = new Random(); //Barajear
    
    public main m;
    private JLabel fichasLbl;
    private JLabel currentBetLbl;
	public void setmain(main m) {
		this.m = m;
	}
	public void regresarBtn(java.awt.event.ActionEvent avt) {
		main.main(null);
		frame.setVisible(false);
		this.setVisible(false);
	}

    public TexasHoldemGame() {
    	if(login.loged) {
        	setTitle("Cuenta registrada como: "+login.user+" - Poker Texas Hold'em");
    	} else {
        	setTitle("Poker Texas Hold'em");
    	}
    	setBackground(new Color(0, 128, 64));
        frame = new JFrame("Texas Hold'em Poker");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(720,650);
        setResizable(false);
        setLocationRelativeTo(null);
        
        divPanel = new JPanel();
        divPanel.setBackground(new Color(0,128,64));
        
        communityPanel = new JPanel();
        communityPanel.setBounds(80, 210, 565, 150);
        communityPanel.setForeground(new Color(255, 255, 255));
        communityPanel.setBackground(new Color(192, 192, 192));
        communityPanel.setLayout(new FlowLayout());
        communityPanel.setBorder(BorderFactory.createTitledBorder("Cartas Comunitarias"));

        communityCards = new ArrayList<>();
        player1Cards = new ArrayList<>();
        
        player2Cards = new ArrayList<>();
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(divPanel, BorderLayout.CENTER);
        divPanel.setLayout(null);
        divPanel.add(communityPanel);
        
        messageArea = new JTextArea();
        messageArea.setSize(376, 148);
        messageArea.setEditable(false);
        messageArea.setWrapStyleWord(true);
        messageArea.setFont(new Font("Arial", Font.PLAIN, 16));
        messageArea.setForeground(new Color(192, 192, 192));
        messageArea.setEnabled(false);
        messageArea.setBackground(new Color(0, 0, 0));
        messageArea.setLocation(1, 1);
        divPanel.add(messageArea);
		
		sp = new JScrollPane(messageArea);
		sp.setSize(448, 150);
		sp.setLocation(10, 385);
		sp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		divPanel.add(sp);

		player1InGame = true;
		
        
		
		playersPanel = new JPanel();
		playersPanel.setBounds(0, 5, 706, 195);
		divPanel.add(playersPanel);
		playersPanel.setBackground(new Color(0, 128, 64));
		playersPanel.setBorder(BorderFactory.createTitledBorder("Jugadores"));
		playersPanel.setLayout(null);
		
		fichasLbl = new JLabel("Fichas: "+main.totalFichas);
		fichasLbl.setHorizontalAlignment(SwingConstants.TRAILING);
		fichasLbl.setFont(new Font("Tahoma", Font.PLAIN, 20));
		fichasLbl.setBounds(445, 95, 250, 45);
		playersPanel.add(fichasLbl);
		
		player1Panel = new JPanel();
		player1Panel.setBounds(10, 15, 320, 170);
		player1Panel.setBackground(new Color(192, 192, 192));
		player1Panel.setLayout(new FlowLayout());
		if(login.loged) {
			player1Panel.setBorder(BorderFactory.createTitledBorder("Cartas de: "+login.user));
		} else {
			player1Panel.setBorder(BorderFactory.createTitledBorder("Cartas de: Jugador 1"));
		}
		playersPanel.add(player1Panel);
		
		potLabel = new JLabel("Pot: 0");
		potLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		potLabel.setBounds(483, 15, 210, 45);
		potLabel.setOpaque(false);
		playersPanel.add(potLabel);
		potLabel.setFont(new Font("Arial", Font.PLAIN, 20));
		
		player1Lbl = new JLabel();
		player1Lbl.setBounds(485, 160, 210, 25);
		playersPanel.add(player1Lbl);
		player1Lbl.setHorizontalAlignment(SwingConstants.TRAILING);
		
		sitOut = new JCheckBox();
		sitOut.setOpaque(false);
		sitOut.setFocusable(false);
		sitOut.setFont(new Font("Tahoma", Font.BOLD, 12));
		sitOut.setBounds(335, 15, 180, 25);
		playersPanel.add(sitOut);
		sitOut.setText("Sit out next round");
		sitOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(sitOut.isSelected()) {
					player1InGame = false;
					sitOut.setText("Siting out next round");
				} else {
					sitOut.setText("Sit out next round");
					player1InGame = true;
				}
			}
		});
		
		playerPosition = new JLabel();
		playerPosition.setFont(new Font("Tahoma", Font.BOLD, 12));
		playerPosition.setBounds(340, 160, 135, 25);
		playersPanel.add(playerPosition);
		
		currentBetLbl = new JLabel("Apuesta actual: "+currentBet);
		currentBetLbl.setFont(new Font("Tahoma", Font.BOLD, 12));
		currentBetLbl.setBounds(340, 115, 140, 25);
		playersPanel.add(currentBetLbl);
		
		        
		actionPanel = new JPanel();
		divPanel.add(actionPanel);
		actionPanel.setSize(706,58);
		actionPanel.setLocation(0,545);
		        
		foldButton = new JButton("Fold");
		foldButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
		foldButton.setBounds(150, 20, 80, 25);
		foldButton.setFocusable(false);
		foldButton.addActionListener(e -> fold("player1"));
		
		regresarBtn = new JButton("Go Back");
		regresarBtn.setBounds(10, 20, 80, 25);
		regresarBtn.setFont(new Font("Tahoma", Font.PLAIN, 13));
		regresarBtn.setFocusable(false);
		regresarBtn.setFocusable(false);
		regresarBtn.addActionListener(e -> regresarBtn(e));
		        
		turnLabel = new JLabel("Turno: Jugador 1");
		turnLabel.setBounds(549, 22, 132, 19);
		turnLabel.setFont(new Font("Arial", Font.BOLD, 16));
		
		checkCallButton = new JButton("Check");
		checkCallButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
		checkCallButton.setBounds(250, 20, 80, 25);
		checkCallButton.setFocusable(false);
		checkCallButton.addActionListener(e -> checkOrCall());
		
		raiseButton = new JButton("Raise");
		raiseButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
		raiseButton.setBounds(435, 20, 80, 25);
		raiseButton.setFocusable(false);
		raiseButton.addActionListener(e -> raise("player1"));
		
		betSpinner = new JSpinner();
		betSpinner.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				int caracter = e.getKeyChar();
				
				// Verificar si la tecla pulsada no es un digito
				if((caracter < '0') ||(caracter > '9') && (caracter !='\b')) {
					e.consume(); // ignorar el evento de teclado
				}
			}
		});
		betSpinner.addMouseWheelListener(new MouseWheelListener() {
			public void mouseWheelMoved(MouseWheelEvent e) {
				int bet = (Integer) betSpinner.getValue();
				betSpinner.setValue(bet-=(e.getWheelRotation())*1000);
				if(bet<=0) {
					raiseButton.setEnabled(false);
					betSpinner.setValue(0);
				} else if(bet>main.totalFichas) {
					betSpinner.setValue(main.totalFichas);
				} else {
					raiseButton.setEnabled(true);
				}
			}
		});
		betSpinner.setBounds(350, 20, 85, 25);
		betSpinner.setModel(new SpinnerNumberModel(0, 0, main.totalFichas, 100));
		betSpinner.setFont(new Font("Tahoma", Font.PLAIN, 13));
		betSpinner.setPreferredSize(new Dimension(85,25));
		actionPanel.setLayout(null);
		actionPanel.add(regresarBtn);
		actionPanel.add(turnLabel);
		actionPanel.add(foldButton);
		actionPanel.add(checkCallButton);
		actionPanel.add(betSpinner);
		actionPanel.add(raiseButton);
		
		playerCardWidth = 80;
		playerCardHeight = 112; 
		
		communityCardWidth = 100;
		communityCardHeight = 114;
		
		playAgain = new JButton("Sit in");
		playAgain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(main.totalFichas>=smallBlind) {
					player1InGame = true;
					resetGame();
				} else {
					JOptionPane.showMessageDialog(null, "Fichas insuficientes para jugar", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
        playAgain.setBounds(535,430,89,28);
		playAgain.setFocusable(false);
		playAgain.setVisible(false);
    	divPanel.add(playAgain);
		
		folded1 = false;
		folded2 = false;
        // Inicializar y mostrar el juego
        initializeGame();
        updateGameArea();
		setVisible(true);
    }
    
    private void initializeGame() {
    	buildDeck();
    	shuffleDeck();
        currentRound = 0; // Comenzar en Pre-Flop
        inGame = true;
        hasBet = false; // No hay apuestas al inicio
        pot = 0; // Inicializar el pot
        player1Turn = true; // Comienza el turno del jugador 1
        player1Checked = false;
        player2Checked = false;
        nextRound();
        if (currentBlindPosition==0) {
            if(main.totalFichas>=smallBlind) {
            	main.totalFichas -= smallBlind;
                pot += bigBlind;
                pot += smallBlind;
                hasBet=true;
            } else {
            	player1InGame=false;
            	sitOut.setSelected(true);
        		resetGame();
            }
        	currentBet=smallBlind;
            hasBet=true;
            checkCallButton.setText("Call");
        	playerPosition.setText("Position: SB");
        } else {
    		playerPosition.setText("Position: BB");
        	if(main.totalFichas>=bigBlind) {
        		main.totalFichas -= bigBlind;
        		pot += bigBlind;
        		pot += smallBlind;
        	} else {
        		player1InGame=false;
        		sitOut.setSelected(true);
        		resetGame();
        	}
        	currentBet = 0;
        }
        potLabel.setText("Pot: "+pot);
        currentBetLbl.setText("Apuesta actual: "+currentBet);
        sitOut.setSelected(false);
        updateGameArea();
        
    }
    
    private void bot1() {
    	Timer timer = new Timer(2000, null); //2 segundos de retraso
    	timer.setInitialDelay(100);
    	timer.setRepeats(false); // Solo queremos que se ejecute una vez

    	timer.addActionListener(e -> {
    		if(inGame) {
    			if (hasBet && !player1Turn) {
    				BettingAfterOpponent();
    			} else if (!hasBet && !player1Turn) {
    				BettingBeforeOpponent();
    			}
    			player1Turn = true;
    			player1Checked = false;
    			checkTurn();
    			checkForNextRound();
    		}
    	});
    	timer.start(); // Iniciar el timer
    	
    }
    
    private void BettingBeforeOpponent() {
    	Hand player2Hand = new Hand(player2Cards, communityCards);
    	double potOdds = player2Hand.calculatePotOdds(currentBet, pot);
    	double outs = player2Hand.calculateOuts();
    	double odds = (outs/deck.size())*100;
        // Lógica para manejar las apuestas antes del oponente
        if (shouldCallOrRaise(potOdds, odds)) {
            if (shouldRaise()) {
                raisePlayer2();
            } else {
                check("player2");
                player2Checked = true;
            }
        } else {
            check("player2");
            player2Checked = true;
        }
    }
    
    private void BettingAfterOpponent() {
    	Hand player2Hand = new Hand(player2Cards, communityCards);
    	double potOdds = player2Hand.calculatePotOdds(currentBet, pot);
    	double outs = player2Hand.calculateOuts();
    	double odds = (outs/deck.size())*100;
        // Lógica para manejar las apuestas después del oponente
        if (shouldCallOrRaise(potOdds, odds)) {
            if (shouldRaise()) {
            	raisePlayer2();
            } else {
                call("player2");
                player2Checked = true;
            }
        } else {
            fold("player2");
        }
    }
    
    private boolean shouldRaise() {
        return new Random().nextBoolean();
    }
    
    private boolean shouldCallOrRaise(double potOdds, double odds) {
        return potOdds > (odds / 100);
    }
    
    private void raisePlayer2() {
        int raiseAmount = calculateRaiseAmount();
        if(raiseAmount>main.totalFichas) {
        	raiseAmount=main.totalFichas;
        }
        if(raiseAmount<currentBet) {
        	raiseAmount=currentBet*=1.5;
        }
        if(raiseAmount%100!=0) {
        	raiseAmount+=50;
        }
        raise("player2", raiseAmount);
    }

    private int calculateRaiseAmount() {
        if (pot != 0 && (pot % 2 == 0)) {
            return pot / 2;
        } else {
            return pot + 200;
        }
    }
    
    private void nextRound() {
        switch (currentRound) {
            case 0: // Pre-Flop
            	dealInitialCards();
            	//System.out.println(player2Cards);
            	inGame=true;
                currentRound++;
                break;
            case 1: //Flop: Repartir 3 cartas comunitarias
            	dealCommunityCards(3,500);
            	inGame=true;
                currentRound++;
                break;
            case 2: // Turn: Repartir 1 carta comunitaria
            	dealCommunityCards(1,500);
            	inGame=true;
            	currentRound++;
                break;
            case 3: // River: Repartir 1 carta comunitaria
            	dealCommunityCards(1,500);
            	inGame=true;
                currentRound++;
                break;
            case 4:
            	endGame();
            	inGame=false;
               // System.exit(0);
            	break;
        }
        regresarBtn.setEnabled(!inGame);
        player1Lbl.setText(getPlayer1HandDescription());
        player1Turn=true;
        currentBetLbl.setText("Apuesta actual: "+currentBet);
        hasBet=false;
        turnLabel.setText("Turno: Jugador 1");
        updateGameArea(); // Actualizar la interfaz después de avanzar la ronda
    }
    
    private void dealInitialCards() {
        for (int i = 0; i < 2; i++) {
            Card card = deck.remove(deck.size() - 1); // Carta
            player1Cards.add(card);
        }
        for (int i = 0; i < 2; i++) {
        	Card card = deck.remove(deck.size() - 1); // Carta
            player2Cards.add(card);
        }
    	
    }
    
    private void dealCommunityCards(int numberOfCards, int delay) {
        Timer timer = new Timer(delay, null);
        timer.setInitialDelay(0); // Sin retraso inicial
        timer.setRepeats(true); // Repetir para cada carta

        // Contador para el número de cartas repartidas
        int[] cardsDealt = {0}; // Usamos un array para poder modificarlo dentro del ActionListener

        timer.addActionListener(e -> {
        	if (cardsDealt[0] < numberOfCards && communityCards.size() < 5) {
                Card card = deck.remove(deck.size() - 1); // Repartir carta
                communityCards.add(card);
                updateGameArea(); // Actualizar la interfaz después de repartir la carta
                cardsDealt[0]++;
            } else {
                timer.stop(); // Detener el timer cuando se hayan repartido todas las cartas
            }
        });
        timer.start(); // Iniciar el timer
    }


    private void resetGame() {
        // Reiniciar las cartas, el pozo, las apuestas, etc.
    	communityCards.clear();
        player1Cards.clear();
        player2Cards.clear();
        player1Panel.revalidate();
        player1Panel.repaint();
        communityPanel.revalidate();
        communityPanel.repaint();
        pot = 0;
        currentBet = 0;
        hasBet = false;
    	folded1=false;
    	folded2=false;
    	currentRound = 0;
    	player1Turn = true;
    	player1Checked = false;
    	player2Checked = false;
    	inGame = true;
    	
        if(player1InGame) {
        	inGame=true;
        	initializeGame();
            // Continuar con la lógica del juego
        } else {
        	communityCards.clear();
            player1Cards.clear();
            player2Cards.clear();
        }
        if(sitOut.isSelected()) {
        	playAgain.setVisible(true);
        	sitOut.setEnabled(false);
        } else {
        	sitOut.setEnabled(true);
        	playAgain.setVisible(false);
        }
    }
    private void endGame() {
    	 // Fin del juego, se pueden determinar los ganadores aquí
    	Hand player1Hand = new Hand(player1Cards, communityCards);
    	Hand player2Hand = new Hand(player2Cards, communityCards);
        player1Evaluation = player1Hand.evaluateHand();
        player2Evaluation = player2Hand.evaluateHand();
        currentRound = 4;
    	determineWinner();
    	updateGameArea();
    	checkCallButton.setText("Check");
    	regresarBtn.setEnabled(!inGame);
    	
    	currentBlindPosition = (currentBlindPosition + 1) % 2;
    	player1Turn=true;
    	inGame=false;
        // Reiniciar el juego para la siguiente ronda
        resetGame();
    }
    
    
    //RAISE PARA EL BOT
    private void raise(String player,int input) {
        
                    pot += input; // Añadir la apuesta al pot
                    currentBet = input; // Actualizar la apuesta actual
                    hasBet = true; // Se ha realizado una apuesta
                    checkCallButton.setText("Call"); // Cambiar el texto del botón
                    potLabel.setText("Pot: "+pot);

                    messageArea.append("Dealer: ");
                        player1Turn = true; // Cambia el turno al jugador 1
                        player1Checked = false; // Reiniciar estado del jugador 1
                        player2Checked = false; // Reiniciar estado del jugador 2
                        turnLabel.setText("Turno: Jugador 1"); // Actualizar el turno
                        currentBetLbl.setText("Apuesta actual: "+currentBet);
                        messageArea.append("Raise del Jugador 2 por "+currentBet+"\n");
                    	messageArea.setForeground(Color.BLACK);
                    	if(main.totalFichas<currentBet) {
                    		raiseButton.setEnabled(false);
                    	}
                    fichasLbl.setText("Fichas: "+main.totalFichas);
                    checkForNextRound();
                    checkTurn(); // Cambiar el turno
                }
    
    //RAISE PARA EL JUGADOR
    private void raise(String player) {
    	int input = 0;
        input = (int) betSpinner.getValue();
            try {
                int raiseAmount = input;
                if (raiseAmount > 0) {
                	if(hasBet && raiseAmount<=currentBet) {
                		JOptionPane.showMessageDialog(null, "La cantidad debe ser mayor a la apuesta actual", "Error", JOptionPane.ERROR_MESSAGE);
                	} else {
                        pot += raiseAmount; // Añadir la apuesta al pot
                        currentBet = raiseAmount; // Actualizar la apuesta actual
                        hasBet = true; // Se ha realizado una apuesta
                        betSpinner.setValue(0);
                        checkCallButton.setText("Call"); // Cambiar el texto del botón
                        potLabel.setText("Pot: "+pot);
                        currentBetLbl.setText("Apuesta actual: "+currentBet);
                        
                        messageArea.append("Dealer: ");
                        	main.totalFichas-=raiseAmount;
                            player1Turn = false; // Cambia el turno al jugador 2
                            player1Checked = false; // Reiniciar estado del jugador 1
                            player2Checked = false; // Reiniciar estado del jugador 2
                            turnLabel.setText("Turno: Jugador 2"); // Actualizar el turno
                            messageArea.append("Raise del Jugador 1 por "+currentBet+ "\n");
                        	messageArea.setForeground(Color.BLACK);
                        
                        fichasLbl.setText("Fichas: "+main.totalFichas);
                        checkForNextRound();
                        checkTurn(); // Cambiar el turno
                	}
                } else {
                    JOptionPane.showMessageDialog(frame, "La cantidad debe ser mayor que 0.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(frame, "Por favor, ingrese un número válido.");
            }
        }
    
 
    
    private void checkOrCall() {
        if (hasBet) {
           call("player1");
        } else {
            check("player1");
        }
        fichasLbl.setText("Fichas: "+main.totalFichas);
        hasBet = false;
        currentBet=0;
        checkForNextRound();
        checkTurn(); // Cambiar el turno
    }
    private void call(String player) {
    	// Si hay una apuesta, se hace un Call
        pot += currentBet; // Igualar la apuesta al pot
        checkCallButton.setText("Check");
        potLabel.setText("Pot: "+pot);

        messageArea.append("Dealer: ");
        
        if(player.equals("player1")) {
        	if(currentBet>main.totalFichas) {
        		currentBet=main.totalFichas;
        		main.totalFichas-=currentBet;
                player1Turn = false; // Cambia el turno al jugador 2
                player1Checked = true; // Reiniciar estado del jugador 1
                player2Checked = false; // Reiniciar estado del jugador 2
                turnLabel.setText("Turno: Jugador 2"); // Actualizar el turno
                messageArea.append("Call del Jugador 1 por "+currentBet + "\n");
            	messageArea.setForeground(Color.BLACK);
        	} else {
        		main.totalFichas-=currentBet;
                player1Turn = false; // Cambia el turno al jugador 2
                player1Checked = true; // Reiniciar estado del jugador 1
                player2Checked = false; // Reiniciar estado del jugador 2
                turnLabel.setText("Turno: Jugador 2"); // Actualizar el turno
                messageArea.append("Call del Jugador 1 por "+currentBet + "\n");
            	messageArea.setForeground(Color.BLACK);
        	}
        	
        	if(main.totalFichas==0) {
            	if(currentRound!=4) {
            		for(int i=currentRound;i<4;i++){
                		nextRound();
            		}
            	}
            }
        	
        } else if(player.equals("player2")) {
            player1Turn = true; // Cambia el turno al jugador 1
            player1Checked = false; // Reiniciar estado del jugador 1
            player2Checked = true; // Reiniciar estado del jugador 2
            turnLabel.setText("Turno: Jugador 1"); // Actualizar el turno
            messageArea.append("Call del Jugador 2 por "+currentBet+ "\n");
        	messageArea.setForeground(Color.BLACK);
        	
            if(main.totalFichas==0) {
            	if(currentRound!=4) {
            		for(int i=currentRound;i<4;i++){
                		nextRound();
            		}
            	}
            }
        }
        fichasLbl.setText("Fichas: "+main.totalFichas);
        currentBet = 0;
    }
    private void check(String player) {
        // Si no hay apuesta, se hace un Check
    	checkCallButton.setText("Check");
        potLabel.setText("Pot: "+pot);
        fichasLbl.setText("Fichas: "+main.totalFichas);

        messageArea.append("Dealer: ");
        
        messageArea.setForeground(Color.GREEN);
    	if(player.equals("player1")){
            player1Turn = false; // Cambia el turno al jugador 2
            player1Checked = true; // Reiniciar estado del jugador 1
            player2Checked = false; // Reiniciar estado del jugador 2
            turnLabel.setText("Turno: Jugador 2"); // Actualizar el turno
            if(!hasBet) {
                messageArea.append("Check del Jugador 1\n");
            	messageArea.setForeground(Color.BLACK);
            }
        } else if(player.equals("player2")) {
            player1Turn = true; // Cambia el turno al jugador 1
            player1Checked = false; // Reiniciar estado del jugador 1
            player2Checked = true; // Reiniciar estado del jugador 2
            turnLabel.setText("Turno: Jugador 1"); // Actualizar el turno
            if(!hasBet) {
                messageArea.append("Check del Jugador 2\n");
            	messageArea.setForeground(Color.BLACK);
            }
        } else {

        	checkForNextRound();
        }
    	fichasLbl.setText("Fichas: "+main.totalFichas);
    }
    
    private void fold(String player) {
        	if (hasBet) {
        		messageArea.append("Dealer: ");
                if(player.equals("player1")) {
                	folded1=true;
                	messageArea.append("Fold del jugador 1\n");
                } else if(player.equals("player2")) {
                	folded2=true;
                	messageArea.append("Fold del jugador 2\n");
                }
                endGame();
            } else {
                JOptionPane.showMessageDialog(frame, "No puedes retirarte si no hay apuesta.");
            }
    }
    
    private void checkForNextRound() {
        if (player1Turn) {
            // Si es el turno del jugador 1, verifica si ha tomado una acción
            if (player2Checked) {
                // Si el jugador 2 ha hecho check, el jugador 1 puede continuar
                nextRound();
            }
        } else {
            // Si el turno del jugador 1 ha terminado, verifica el turno del jugador 2
            if (player1Checked && player2Checked) {
                // Ambos han hecho check, avanzar a la siguiente ronda
                nextRound();
            } else if (player1Checked && !hasBet) {
                // Jugador 1 ha hecho check y no hay apuesta, se permite que el jugador 2 haga su jugada
                player1Turn = false; // El turno pasa al jugador 2
                bot1();
            } else if (!player1Checked && hasBet) {
                // Jugador 1 ha hecho una apuesta, el jugador 2 debe decidir
            	player1Turn=false;
            	bot1();
            } else if(!inGame) {
            	currentRound--;
            }
        }
        updateGameArea();
    }
    
    private void checkTurn() {
        if (player1Turn) {
            if (player1Checked && player2Checked) {
                // Ambos han hecho check, avanzar a la siguiente ronda
                nextRound();
            } else if (!player1Checked) {
                // El jugador 1 aún no ha hecho su acción
            	player1Turn=true;
                turnLabel.setText("Turno: Jugador 1");
            } else {
                // Si el jugador 1 ha hecho una acción, el turno pasa al jugador 2
                player1Turn = false;
                turnLabel.setText("Turno: Jugador 2");
            }
        } else {
            if (player2Checked) {
            	player1Turn=true;
                turnLabel.setText("Turno: Jugador 1");
                // Si el jugador 2 ha hecho check, avanzar a la siguiente ronda
                nextRound();
            } else {
                // El jugador 2 aún no ha hecho su acción
            	player1Turn=false;
                turnLabel.setText("Turno: Jugador 2");
            }
        }
    }
    
    public void buildDeck() {
        deck = new ArrayList<Card>();
        String[] values = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        String[] types = {"C", "D", "H", "S"};

        for (int i = 0; i < types.length; i++) {
            for (int j = 0; j < values.length; j++) {
                Card card = new Card(values[j], types[i]);
                deck.add(card);
            }
        }
    }
    
    public void shuffleDeck() {
        for (int i = 0; i < deck.size(); i++) {
            int j = random.nextInt(deck.size());
            Card currCard = deck.get(i);
            Card randomCard = deck.get(j);
            deck.set(i, randomCard);
            deck.set(j, currCard);
        }
    }

    private void updateGameArea() {
    	try {
    	betSpinner.setModel(new SpinnerNumberModel(currentBet*2, currentBet, main.totalFichas, 100));
    	} catch(Exception e) {
    		//JOptionPane.showMessageDialog(null, "Fichas insuficientes", "Error", JOptionPane.ERROR_MESSAGE);
    	}
        if(!player1Turn) {
        	checkCallButton.setVisible(false);
        	foldButton.setVisible(false);
        	raiseButton.setVisible(false);
        	betSpinner.setVisible(false);
        } else {
        	checkCallButton.setVisible(true);
        	foldButton.setVisible(true);
        	raiseButton.setVisible(true);
        	betSpinner.setVisible(true);
        }
        player1Lbl.setText(getPlayer1HandDescription());
        
        player1Panel.removeAll();
        communityPanel.removeAll(); // Limpiar el panel de cartas comunitarias
        
        try {
        // Mostrar cartas del jugador 1
        for (int i = 0; i < player1Cards.size(); i++) {
            Card card = player1Cards.get(i);
            Image cardImg = new ImageIcon(getClass().getResource(card.getImagePath())).getImage();
            
            Image cardImg1 = cardImg.getScaledInstance(playerCardWidth, playerCardHeight, Image.SCALE_SMOOTH);
            
            JLabel cardLabel = new JLabel(new ImageIcon(cardImg1));
            player1Panel.add(cardLabel); // Agregar la imagen de la carta al panel
        }
        fichasLbl.setText("Fichas: "+main.totalFichas);

        // Mostrar cartas comunitarias
        for (Card card : communityCards) {
            Image cardImg = new ImageIcon(getClass().getResource(card.getImagePath())).getImage();
            
            Image cardImg1 = cardImg.getScaledInstance(communityCardWidth, communityCardHeight, Image.SCALE_SMOOTH);
            
            JLabel cardLabel = new JLabel(new ImageIcon(cardImg1));
            communityPanel.add(cardLabel); // Agregar la imagen de la carta al panel
        }
        
        // Hacer el repaint en el player 1
        player1Panel.revalidate();
        player1Panel.repaint();
        // Hacer el repaint en el player 2

        communityPanel.revalidate(); 
        communityPanel.repaint(); 
        // Hacer el repaint en las cartas comunitarias
        } catch(Exception e) {
        	e.printStackTrace();
        }
    }
    
    private String getPlayer1HandDescription() {
        Hand player1Hand = new Hand(player1Cards, communityCards);
        List<Card> player1 = new ArrayList<>(player1Cards);
        player1.addAll(communityCards);
        player1Evaluation = player1Hand.evaluateHand();
        return getHandDescription(player1Evaluation, player1);
    }
    
    private String getHandDescription(Hand.HandEvaluation evaluation, List<Card> cards) {
        String description = "";
        switch (evaluation.rank) {
            case 9:
                description = "Straight Flush";
                break;
            case 8:
                description = "Four of a Kind";
                break;
            case 7:
                description = "Full House (" + getFullHouseDescription(cards) + ")";
                break;
            case 6:
                description = "Flush";
                break;
            case 5:
                description = "Straight";
                break;
            case 4:
                description = "Three of a Kind of " + getThreeOfAKindDescription(cards);
                break;
            case 3:
                description = "Two Pair (" + getTwoPairDescription(cards) + ")";
                break;
            case 2:
                description = "A Pair of " + getPairDescription(cards);
                break;
            case 1:
                int highCard = getHighCardValue(cards);
                description = "High Card " + getCardName(highCard);
                break;
        }
        return description;
    }

    private int getHighCardValue(List<Card> cards) {
        return cards.stream()
                    .mapToInt(Card::getValue)
                    .max()
                    .orElse(0); // Devuelve 0 si no hay cartas
    }

    private String getCardName(int value) {
    	switch (value) {
	    	case 2: return "2";
	    	case 3: return "3";
	    	case 4: return "4";
	    	case 5: return "5";
	    	case 6: return "6";
	    	case 7: return "7";
	    	case 8: return "8";
	    	case 9: return "9";
	    	case 10: return "10";
            case 11: return "Jack";
            case 12: return "Queen";
            case 13: return "King";
            case 14: return "Ace";
            default: return String.valueOf(value);
        }
    }
    
    private String getFullHouseDescription(List<Card> cards) {
        Map<String, Integer> rankCount = getRankCount(cards);
        String threeOfAKindRank = rankCount.entrySet().stream()
                .filter(entry -> entry.getValue() == 3)
                .map(Map.Entry::getKey)
                .findFirst()
                .orElse("Unknown");
        String pairRank = rankCount.entrySet().stream()
                .filter(entry -> entry.getValue() == 2)
                .map(Map.Entry::getKey)
                .findFirst()
                .orElse("Unknown");
        return threeOfAKindRank + "s full of " + pairRank + "s"; // Asegúrate de que esto sea correcto
    }

    
	// Método para obtener la descripción de un Three of a Kind
    private String getThreeOfAKindDescription(List<Card> cards) {
        Map<String, Integer> rankCount = getRankCount(cards);
        String threeOfAKindRank = rankCount.entrySet().stream()
                .filter(entry -> entry.getValue() == 3)
                .map(Map.Entry::getKey)
                .findFirst()
                .orElse("Unknown");
        return threeOfAKindRank + "s";
    }

    // Método para obtener la descripción de un Two Pair
    private String getTwoPairDescription(List<Card> cards) {
        Map<String, Integer> rankCount = getRankCount(cards);
        // Imprimir el conteo de rangos para depuración
        //System.out.println("Rank Count: " + rankCount);

        List<String> pairs = rankCount.entrySet().stream()
                .filter(entry -> entry.getValue() == 2)
                .map(Map.Entry::getKey)
                .toList();

        // Verificar que hay exactamente dos pares
        if (pairs.size() == 2) {
            return pairs.get(0) + "s and " + pairs.get(1) + "s"; // Asumiendo que hay exactamente dos pares
        } else {
            return "Not enough pairs"; // O manejar el caso de otra manera
        }
    }

    // Método para obtener la descripción de un Pair
    private String getPairDescription(List<Card> cards) {
        Map<String, Integer> rankCount = getRankCount(cards);
        return rankCount.entrySet().stream()
                .filter(entry -> entry.getValue() == 2)
                .map(Map.Entry::getKey)
                .findFirst()
                .orElse("Unknown");
    }
    private Map<String, Integer> getRankCount(List<TexasHoldemGame.Card> cards) {
    	 Map<String, Integer> rankCount = new HashMap<>();
	        for (Card card : cards) {
	            rankCount.put(card.rank, rankCount.getOrDefault(card.rank, 0) + 1);
	        }
	        return rankCount;
	}
    
    private int determineWinnerBetweenHands(Hand.HandEvaluation evaluation1, Hand.HandEvaluation evaluation2, Hand player1Hand, Hand player2Hand) {
        if (evaluation1.rank > evaluation2.rank) {
            messageArea.append("Player 1 wins with " + getPlayer1HandDescription() +"\n");
            return 1;
        } else if (evaluation1.rank < evaluation2.rank) {
            String winnerCombination = getHandDescription(evaluation2, player2Hand.getAllCards());
            messageArea.append("Player 2 wins with " + winnerCombination+"\n");
            return 2;
        } else {
            // Comparar valores primarios y secundarios
            if (evaluation1.primaryValue > evaluation2.primaryValue) {
                messageArea.append("Player 1 wins with " + getPlayer1HandDescription()+"\n");
                return 1;
            } else if (evaluation1.primaryValue < evaluation2.primaryValue) {
                String winnerCombination = getHandDescription(evaluation2, player2Hand.getAllCards());
                messageArea.append("Player 2 wins with " + winnerCombination+"\n");
                return 2;
            } else {
                // Comparar valores secundarios
                if (evaluation1.secondaryValue > evaluation2.secondaryValue) {
                    messageArea.append("Player 1 wins with " + getPlayer1HandDescription()+"\n");
                    return 1;
                } else if (evaluation1.secondaryValue < evaluation2.secondaryValue) {
                    String winnerCombination = getHandDescription(evaluation2, player2Hand.getAllCards());
                    messageArea.append("Player 2 wins with " + winnerCombination+"\n");
                    return 2;
                } else {
                    // Si ambos tienen la misma combinación, se verifica la carta más alta
                    return determineHighCardWinner(player1Hand, player2Hand);
                }
            }
        }
    }
    
    private int determineHighCardWinner(Hand player1Hand, Hand player2Hand) {
        int highCard1 = player1Hand.getHighCardValue(player1Cards);
        int highCard2 = player2Hand.getHighCardValue(player2Cards);

        if (highCard1 > highCard2) {
            messageArea.append("Player 1 wins with " + getPlayer1HandDescription()+"\n");
            return 1;
        } else if (highCard1 < highCard2) {
        	String winnerCombination = getHandDescription(player2Evaluation, player2Hand.getAllCards());
            messageArea.append("Player 2 wins with " + winnerCombination+"\n");
            return 2;
        } else {
            messageArea.append("It's a tie! \n");
            return 3;
        }
    }
    private void updateGameResult(int player1Wins) {
        inGame = false;
        if (player1Wins == 1) {
            main.totalFichas += pot;
        } else if (player1Wins == 3) {
            main.totalFichas += pot / 2;
        } else {
            System.out.println("You lose");
        }
    }
    
    private void determineWinner() {
    	if(!inGame) return;
    	messageArea.setForeground(new Color(192, 192, 192));
        messageArea.append("\nPlayer 2 cards: " + player2Cards + "\n");
        messageArea.append("Board cards: "+communityCards + "\n");

        Hand player1Hand = new Hand(player1Cards, communityCards);
        Hand player2Hand = new Hand(player2Cards, communityCards);
        player1Evaluation = player1Hand.evaluateHand();
        player2Evaluation = player2Hand.evaluateHand();

        // Manejar jugadores que se retiran
        if (folded1) {
            player1Evaluation.rank = -1; // Asignar un valor que indique que el jugador se ha retirado
        }
        if (folded2) {
            player2Evaluation.rank = -1; // Asignar un valor que indique que el jugador se ha retirado
        }
     // Determinar el ganador
        int player1Wins = determineWinnerBetweenHands(player1Evaluation, player2Evaluation, player1Hand, player2Hand);
        
        // Actualizar el mensaje y las fichas
        updateGameResult(player1Wins);
        messageArea.append("---------- Next Hand ----------\n");
    	
    	pot=0;
    	potLabel.setText("Pot: "+pot);
        try {
        	
        	PreparedStatement ps;
        	String URL = "jdbc:mysql://localhost:3306/registroskas_bd";
        	String USER = "root";
        	String PASSW = "";
        	try (Connection conn = DriverManager.getConnection(URL, USER, PASSW)){
        		String SQL = "UPDATE users SET fichasT=? where user_n=?";
        		ps = conn.prepareStatement(SQL);
        		ps.setInt(1, main.totalFichas);
        		ps.setString(2, login.user);
        		int resul = ps.executeUpdate();
        		if(resul>0) {
        			System.out.println("Conexion exitosa");
        		} else {
        			System.out.println("Conexion fallida");
        		}
        		conn.close();
        	} catch (SQLException e1) {
        		e1.printStackTrace();
        	}
        } catch (Exception e) {
        		e.printStackTrace();
        }
    }

    class Card {
        private String rank;
        private String suit;

        public Card(String rank, String suit) {
            this.rank = rank;
            this.suit = suit;
        }
        
        
        
        
        public int getRank1() {
            switch (rank) {
                case "2": return 2;
                case "3": return 3;
                case "4": return 4;
                case "5": return 5;
                case "6": return 6;
                case "7": return 7;
                case "8": return 8;
                case "9": return 9;
                case "10": return 10;
                case "J": return 11;
                case "Q": return 12;
                case "K": return 13;
                case "A": return 14;
                default: throw new IllegalArgumentException("Invalid rank: " + rank);
            }
        }
        
        public int getValue() {
            switch (rank) {
                case "J": return 11;
                case "Q": return 12;
                case "K": return 13;
                case "A": return 14;
                default: return 0; // error
            }
        }
        public String getSuit() {
            return suit;
        }
        public String getRank() {
            return rank;
        }


        public String toString() {
            return rank + "-" + suit;
        }
        
        public String getImagePath() {
            return "./cards/" + toString() + ".png";
        }
    }
    
    class Hand {
    	 private List<Card> playerCards;
    	 private List<Card> communityCards;

    	    public Hand(List<Card> playerCards, List<Card> communityCards) {
    	    	this.playerCards = new ArrayList<>(playerCards);
    	        this.communityCards = new ArrayList<>(communityCards);
    	    }
    	    
    	    public List<Card> getAllCards() {
    	        List<Card> allCards = new ArrayList<>(playerCards);
    	        allCards.addAll(communityCards);
    	        return allCards;
    	    }
    	    private int rankToValue(String rank) {
    	        switch (rank) {
    	            case "2": return 2;
    	            case "3": return 3;
    	            case "4": return 4;
    	            case "5": return 5;
    	            case "6": return 6;
    	            case "7": return 7;
    	            case "8": return 8;
    	            case "9": return 9;
    	            case "10": return 10;
    	            case "J": return 11;
    	            case "Q": return 12;
    	            case "K": return 13;
    	            case "A": return 14;
    	            default: throw new IllegalArgumentException("Invalid rank: " + rank);
    	        }
    	    }
    	    
    	    public int calculateOuts() {
    	        int outs = 0;
    	        Map<String, Integer> rankCount = new HashMap<>();

    	        // Contamos las cartas en la mano del jugador
    	        for (Card card : playerCards) {
    	            rankCount.put(card.getRank(), rankCount.getOrDefault(card.getRank(), 0) + 1);
    	        }

    	        // Contamos las cartas comunitarias
    	        for (Card card : communityCards) {
    	            rankCount.put(card.getRank(), rankCount.getOrDefault(card.getRank(), 0) + 1);
    	        }

    	        // Calculamos outs para pares, tríos y full
    	        for (String rank : rankCount.keySet()) {
    	            if (rankCount.get(rank) == 1) {
    	                // Si hay un solo par, necesitamos otro para hacer un trío
    	                outs += countRemainingCards(rank);
    	            } else if (rankCount.get(rank) == 2) {
    	                // Si hay un trío, necesitamos otro para hacer un full
    	                outs += countRemainingCards(rank);
    	            }
    	        }

    	        // Calculamos outs para proyectos de escalera
    	        outs += calculateStraightOuts();

    	        // Calculamos outs para proyectos de color
    	        outs += calculateFlushOuts();

    	        return outs;
    	    }

    	    private int countRemainingCards(String rank) {
    	        // Hay 4 cartas de cada rango en total
    	        int total = 4;
    	        int inHand = 0;

    	        // Contamos cuántas cartas de este rango hay en la mano y en las comunitarias
    	        for (Card card : playerCards) {
    	            if (card.getRank().equals(rank)) {
    	                inHand++;
    	            }
    	        }
    	        for (Card card : communityCards) {
    	            if (card.getRank().equals(rank)) {
    	                inHand++;
    	            }
    	        }

    	        return total - inHand; // Cartas restantes de este rango
    	    }

    	    private int calculateStraightOuts() {
    	        // Crear un conjunto de rangos de cartas en la mano y en las comunitarias
    	        List<String> allCards = new ArrayList<>();
    	        for (Card card : playerCards) {
    	            allCards.add(card.getRank());
    	        }
    	        for (Card card : communityCards) {
    	            allCards.add(card.getRank());
    	        }

    	        // Convertir los rangos a valores numéricos para facilitar el cálculo
    	        Map<String, Integer> rankValue = new HashMap<>();
    	        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    	        for (int i = 0; i < ranks.length; i++) {
    	            rankValue.put(ranks[i], i);
    	        }

    	        // Contar cuántas cartas de cada rango están presentes
    	        boolean[] present = new boolean[15]; // 0-12 para 2-A, 13 para el "5" de la escalera baja
    	        for (String rank : allCards) {
    	            present[rankValue.get(rank)] = true;
    	        }

    	        int outs = 0;

    	        // Verificar posibles escalera
    	        for (int i = 0; i < present.length - 4; i++) { // Solo necesitamos verificar hasta el "10"
    	            if (present[i] && present[i + 1] && present[i + 2] && present[i + 3]) {
    	                // Si tenemos 4 cartas en secuencia, contamos las outs
    	                if (!present[i + 4]) {
    	                    outs++; // La carta que completa la escalera
    	                }
    	                if (i > 0 && !present[i - 1]) {
    	                    outs++; // La carta que completa la escalera hacia abajo
    	                }
    	            }
    	        }

    	        return outs;
    	    }

    	    private int calculateFlushOuts() {
    	        int outs = 0;
    	        Map<String, Integer> suitCount = new HashMap<>();

    	        // Contamos las cartas en la mano del jugador
    	        for (Card card : playerCards) {
    	            suitCount.put(card.getSuit(), suitCount.getOrDefault(card.getSuit(), 0) + 1);
    	        }

    	        // Contamos las cartas comunitarias
    	        for (Card card : communityCards) {
    	            suitCount.put(card.getSuit(), suitCount.getOrDefault(card.getSuit(), 0) + 1);
    	        }

    	        // Buscamos el palo con más cartas
    	        for (String suit : suitCount.keySet()) {
    	            int count = suitCount.get(suit);
    	            if (count >= 4) { // Si ya tenemos 4 cartas de un mismo palo
    	                outs += countRemainingCardsOfSuit(suit); // Contamos las cartas restantes de ese palo
    	            }
    	        }

    	        return outs;
    	    }
    	    
    	    public double calculatePotOdds(int bet, int pot) {
    	        return (double) bet / pot;
    	    }

    	    private int countRemainingCardsOfSuit(String suit) {
    	        // Hay 13 cartas de cada palo en total
    	        int total = 13;
    	        int inHand = 0;

    	        // Contamos cuántas cartas de este palo hay en la mano y en las comunitarias
    	        for (Card card : playerCards) {
    	            if (card.getSuit().equals(suit)) {
    	                inHand++;
    	            }
    	        }
    	        for (Card card : communityCards) {
    	            if (card.getSuit().equals(suit)) {
    	                inHand++;
    	            }
    	        }

    	        return total - inHand; // Cartas restantes de este palo
    	    }
    	
    	    public HandEvaluation evaluateHand() {
    	        List<Card> allCards = new ArrayList<>(playerCards);
    	        allCards.addAll(communityCards);

    	        // Evaluar la mano y devolver un objeto de evaluación
    	        return evaluateHandWithTieBreaker(allCards);
    	    }

    	    private HandEvaluation evaluateHandWithTieBreaker(List<Card> cards) {
    	        if (isStraightFlush(cards)) 
    	        	return new HandEvaluation(9,getHighCardValue(cards), getKickerValue(cards));
    	         if (isFourOfAKind(cards)) 
    	        	return new HandEvaluation(8, getFourOfAKindValue(cards), getKickerValue(cards));
    	         if (isFullHouse(cards)) 
    	        	return new HandEvaluation(7, getFullHouseValue(cards), getKickerValue(cards));
    	         if (isFlush(cards)) 
    	        	return new HandEvaluation(6, getFlushHighCard(cards), getKickerValue(cards));
    	         if (isStraight(cards)) 
    	        	return new HandEvaluation(5, getStraightHighCard(cards), getKickerValue(cards));
    	         if (isThreeOfAKind(cards))
    	        	return new HandEvaluation(4, getThreeOfAKindValue(cards), getKickerValue(cards));
    	         if (isTwoPair(cards))
    	        	return new HandEvaluation(3, getTwoPairValue(cards), getKickerValue(cards));
    	         if (isOnePair(cards))
    	        	return new HandEvaluation(2, getPairValue(cards), getKickerValue(cards));
    	        return new HandEvaluation(1, getHighCardValue(cards)); // Carta alta
    	    }

    	    // Métodos de evaluación de manos
    	    private boolean isStraightFlush(List<Card> cards) {
    	        return isStraight(cards) && isFlush(cards);
    	    }

    	    private boolean isFourOfAKind(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        return rankCount.containsValue(4);
    	    }

    	    private boolean isFullHouse(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        return rankCount.containsValue(3) && rankCount.containsValue(2);
    	    }

    	    private boolean isFlush(List<Card> cards) {
    	    	 Map<String, Long> suitCount = cards.stream()
    	    		        .collect(Collectors.groupingBy(Card::getSuit, Collectors.counting()));
    	    	 return suitCount.values().stream().anyMatch(count -> count >= 5);
    	    }

    	    private boolean isStraight(List<Card> cards) {
    	    	Set<Integer> uniqueRanks = new HashSet<>();
    	        for (Card card : cards) {
    	            uniqueRanks.add(card.getRank1());
    	        }

    	        List<Integer> sortedRanks = new ArrayList<>(uniqueRanks);
    	        Collections.sort(sortedRanks);

    	        // Verificar si hay cinco cartas consecutivas
    	        for (int i = 0; i <= sortedRanks.size() - 5; i++) {
    	            if (sortedRanks.get(i + 4) - sortedRanks.get(i) == 4) {
    	                return true; // Se encontró una escalera
    	            }
    	        }

    	        // Verificar el caso especial de A-2-3-4-5
    	        if (uniqueRanks.contains(14) && uniqueRanks.contains(2) && uniqueRanks.contains(3) &&
    	            uniqueRanks.contains(4) && uniqueRanks.contains(5)) {
    	            return true; // Escalera A-2-3-4-5
    	        }

    	        return false; // No se encontró escalera
    	    }
    	    private boolean isThreeOfAKind(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        return rankCount.containsValue(3);
    	    }

    	    private boolean isTwoPair(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        return rankCount.values().stream().filter(count -> count == 2).count() == 2;
    	    }

    	    private boolean isOnePair(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        long pairCount = rankCount.values().stream().filter(count -> count == 2).count();
    	        return pairCount == 1; // Debe haber exactamente 1 par
    	    }
    	    
    	    private Map<String, Integer> getRankCount(List<Card> cards) {
    	        Map<String, Integer> rankCount = new HashMap<>();
    	        for (Card card : cards) {
    	            String rank = card.getRank(); // Asegúrate de que getRank devuelva un String
    	            rankCount.put(rank, rankCount.getOrDefault(rank, 0) + 1);
    	        }
    	        return rankCount;
    	    }

    	    // Métodos para obtener valores de manos específicas
    	    private int getPairValue(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        return rankCount.entrySet().stream()
    	                .filter(entry -> entry.getValue() == 2)
    	                .map(entry -> new Card(entry.getKey(), ""))
    	                .mapToInt(Card::getValue)
    	                .max()
    	                .orElse(0);
    	    }
    	    
    	    private int getKickerValue(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        return rankCount.entrySet().stream()
    	                .filter(entry -> entry.getValue() == 1) // Solo cuenta las cartas que no forman parte de una mano
    	                .map(entry -> rankToValue(entry.getKey())) // Convierte el rango de String a int usando rankToValue
    	                .mapToInt(Integer::intValue) // Convierte a int
    	                .max()
    	                .orElse(0);
    	    }

    	    private int getTwoPairValue(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        return rankCount.entrySet().stream()
    	                .filter(entry -> entry.getValue() == 2)
    	                .map(entry -> new Card(entry.getKey(), ""))
    	                .mapToInt(Card::getValue)
    	                .max()
    	                .orElse(0);
    	    }

    	    private int getThreeOfAKindValue(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        return rankCount.entrySet().stream()
    	                .filter(entry -> entry.getValue() == 3)
    	                .map(entry -> new Card(entry.getKey(), ""))
    	                .mapToInt(Card::getValue)
    	                .max()
    	                .orElse(0);
    	    }

    	    private int getFourOfAKindValue(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        return rankCount.entrySet().stream()
    	                .filter(entry -> entry.getValue() == 4)
    	                .map(entry -> new Card(entry.getKey(), ""))
    	                .mapToInt(Card::getValue)
    	                .findFirst()
    	                .orElse(0);
    	    }

    	    private int getFullHouseValue(List<Card> cards) {
    	        Map<String, Integer> rankCount = getRankCount(cards);
    	        int threeOfAKindValue = rankCount.entrySet().stream()
    	                .filter(entry -> entry.getValue() == 3)
    	                .map(entry -> new Card(entry.getKey(), ""))
    	                .mapToInt(Card::getValue)
    	                .findFirst()
    	                .orElse(0);
    	        int pairValue = rankCount.entrySet().stream()
    	                .filter(entry -> entry.getValue() == 2)
    	                .map(entry -> new Card(entry.getKey(), ""))
    	                .mapToInt(Card::getValue)
    	                .findFirst()
    	                .orElse(0);
    	        return threeOfAKindValue * 100 + pairValue; // Multiplicamos para dar prioridad al trío
    	    }

    	    private int getFlushHighCard(List<Card> cards) {
    	        return cards.stream()
    	                .mapToInt(Card::getValue)
    	                .max()
    	                .orElse(0);
    	    }

    	    private int getStraightHighCard(List<Card> cards) {
    	        Set<Integer> values = new HashSet<>();
    	        for (Card card : cards) {
    	            values.add(card.getValue());
    	        }
    	        List<Integer> sortedValues = new ArrayList<>(values);
    	        Collections.sort(sortedValues);
    	        return sortedValues.get(sortedValues.size() - 1); // La carta más alta de la escalera
    	    }
    	    
    	    private int getHighCardValue(List<Card> cards) {
    	        return cards.stream()
    	                .mapToInt(Card::getValue)
    	                .max()
    	                .orElse(0);
    	    }

    	    // Clase para representar la evaluación de la mano
    	    class HandEvaluation {
    	        int rank; // Tipo de mano (9 = Straight Flush, 8 = Four of a Kind, etc.)
    	        int primaryValue; // Valor principal para desempate
    	        int secondaryValue; // Valor secundario para desempate (opcional)
    	        int terciaryValue; // Valor secundario para desempate (opcional)

    	        public HandEvaluation(int rank, int primaryValue) {
    	            this.rank = rank;
    	            this.primaryValue = primaryValue;
    	            this.secondaryValue = 0; // Valor secundario no se usa aquí
    	            this.terciaryValue = 0;
    	        }

    	        public HandEvaluation(int rank, int primaryValue, int secondaryValue) {
    	        	this.rank = rank;
    	            this.primaryValue = primaryValue;
    	            this.secondaryValue = secondaryValue; // Valor secundario para desempate
    	            this.terciaryValue = 0;
    	            
    	        }
    	        
    	        public HandEvaluation(int rank, int primaryValue, int secondaryValue, int terciaryValue) {
    	        	this.rank = rank;
    	            this.primaryValue = primaryValue;
    	            this.secondaryValue = secondaryValue; // Valor secundario para desempate
    	            this.terciaryValue = terciaryValue;
    	        }
    	        @Override
    	        public String toString() {
    	            return "HandEvaluation{" +
    	                    "rank=" + rank +
    	                    ", primaryValue=" + primaryValue +
    	                    ", secondaryValue=" + secondaryValue +
    	                    '}';
    	        }
    	    }
    }
}