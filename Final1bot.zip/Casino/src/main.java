import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class main extends JFrame {
	
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public static boolean pagado=true;
	public static int pago = 0;
	public static int totalFichas=1000;
	
	public static JLabel userLbl;
	public static JButton registerBtn;
	public static JButton logoutBtn;
	public static JLabel fichasLbl;
	private JButton btnBJ;
	public static JButton btnFichas;
	JButton btnPoker;
	
	public void setPagoT(pagoT pt) {
	}
	private void continuarBtn(java.awt.event.ActionEvent avt) {
		fichasM fm  = new fichasM();
		fm.setmain(this);
		fm.setVisible(true);
		this.setVisible(false);
	}
	private void continuarBjBtn(java.awt.event.ActionEvent avt) {
		BlackJack bj  = new BlackJack();
		bj.setmain(this);
		bj.setVisible(true);
		this.setVisible(false);
	}
	private void continuarPkBtn(java.awt.event.ActionEvent avt) {
		TexasHoldemGame pk  = new TexasHoldemGame();
		pk.setmain(this);
		pk.setVisible(true);
		this.setVisible(false);
	}
	private void continuarLogin(java.awt.event.ActionEvent avt) {
		login l= new login();
		l.setmain(this);
		l.setVisible(true);
		this.setVisible(false);
	}
	public static void main(String[] args) {
	EventQueue.invokeLater(new Runnable() {
		public void run() {
			try {
				main frame = new main();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
	});
	}

/**
* Create the frame.
*/
public main() {
	addKeyListener(new KeyAdapter() {
		@Override
		public void keyPressed(KeyEvent e) {
			char c = e.getKeyChar();
			if(c==KeyEvent.VK_SPACE) {
				registerBtn.doClick();
			}
			if(c==KeyEvent.VK_P) {
				btnPoker.doClick();
			}
			if(c==KeyEvent.VK_B) {
				btnBJ.doClick();
			}
		}
	});
	setResizable(false);
	setTitle("Casino KaS");
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setSize(500, 400);
	setLocationRelativeTo(null);
	contentPane = new JPanel();
	contentPane.setBackground(new Color(0, 128, 64));
	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

	setContentPane(contentPane);
	contentPane.setLayout(null);

	btnPoker = new JButton("POKER");
	btnPoker.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			continuarPkBtn(e);
		}
	});
	btnPoker.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btnPoker.setFocusable(false);
	btnPoker.setBounds(250, 150, 120, 50);
	contentPane.add(btnPoker);
	
	btnBJ = new JButton("BLACKJACK");
	btnBJ.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			continuarBjBtn(e);
		}
	});
	btnBJ.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btnBJ.setFocusable(false);
	btnBJ.setBounds(110, 150, 120, 50);
	contentPane.add(btnBJ);
	
	btnFichas = new JButton("FICHAS");
	btnFichas.setToolTipText("Inicie sesion");
	btnFichas.setEnabled(false);
	btnFichas.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		continuarBtn(e);
	}
});
btnFichas.setFont(new Font("Tahoma", Font.PLAIN, 15));
btnFichas.setBounds(180, 210, 120, 50);
btnFichas.setFocusable(false);
contentPane.add(btnFichas);

JLabel lblNewLabel = new JLabel("SELECCIONE OPCION");
lblNewLabel.setForeground(new Color(255, 255, 255));
lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
lblNewLabel.setBounds(10, 10, 465, 30);
contentPane.add(lblNewLabel);


fichasLbl = new JLabel("Cantidad de fichas: "+totalFichas);

fichasLbl.setForeground(new Color(255, 255, 255));
fichasLbl.setFont(new Font("Tahoma", Font.BOLD, 20));
fichasLbl.setHorizontalAlignment(SwingConstants.CENTER);
fichasLbl.setBounds(10, 100, 465, 50);
contentPane.add(fichasLbl);


registerBtn = new JButton("Iniciar sesion");
registerBtn.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		continuarLogin(e);
	}
});
registerBtn.setFont(new Font("Tahoma", Font.PLAIN, 13));
registerBtn.setBounds(10, 310, 110, 30);
registerBtn.setFocusable(false);
contentPane.add(registerBtn);
registerBtn.setVisible(true);

userLbl = new JLabel();
userLbl.setHorizontalAlignment(SwingConstants.TRAILING);
userLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
userLbl.setForeground(new Color(255, 255, 255));
userLbl.setBounds(130, 310, 345, 30);
contentPane.add(userLbl);

logoutBtn = new JButton("Cerrar sesion");
logoutBtn.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(null, "Sesion cerrada correctamente", "Notificacion", JOptionPane.CLOSED_OPTION);
			totalFichas=0;
			fichasLbl.setText("Cantidad de fichas: "+main.totalFichas);
			registerBtn.setVisible(true);
			registerBtn.setEnabled(true);
			logoutBtn.setEnabled(false);
			logoutBtn.setVisible(false);
			btnFichas.setEnabled(false);
			userLbl.setVisible(false);
			btnFichas.setToolTipText("Inicie sesion");
	}
});
logoutBtn.setFont(new Font("Tahoma", Font.PLAIN, 13));
logoutBtn.setBounds(10, 310, 110, 30);
logoutBtn.setFocusable(false);
logoutBtn.setVisible(false);
contentPane.add(logoutBtn);

if(login.loged==true) {
	main.registerBtn.setVisible(false);
	main.registerBtn.setEnabled(false);
	main.logoutBtn.setEnabled(true);
	main.logoutBtn.setVisible(true);
	main.userLbl.setText("Sesion iniciada como: "+login.user);
	main.btnFichas.setEnabled(true);
	main.btnFichas.setToolTipText(null);
	
}



}
}