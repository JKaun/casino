import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JCheckBox;

public class login extends JFrame {
	
	MySqlConn con = new MySqlConn();
	Connection cn=con.conexion();
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	static JTextField userTF;
	static JTextField temp1;
	static String tarj;
	static JPasswordField passTF;
	private JButton confirmBtn;
	static String user;
	
	public static boolean loged;
	private main m;
	public void setmain(main m) {
		this.m = m;
	}
	public void regresarBtn(java.awt.event.ActionEvent avt) {
		m.setVisible(true);
		this.setVisible(false);
	}
	private void continuarRegis(java.awt.event.ActionEvent avt) {
		register r= new register();
		r.setlogin(this);
		r.setVisible(true);
		this.setVisible(false);
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setTitle("Login de usuarios KaS");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(10, 150, 75));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		temp1 = new JTextField();
		JLabel userLbl = new JLabel("Usuario");
		userLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
		userLbl.setBounds(40, 60, 170, 30);
		contentPane.add(userLbl);
		
		JLabel passwLbl = new JLabel("Contraseña");
		passwLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
		passwLbl.setBounds(40, 130, 170, 30);
		contentPane.add(passwLbl);
		
		userTF = new JTextField();
		userTF.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				char c = e.getKeyChar();
				if(c==KeyEvent.VK_ENTER) {
					confirmBtn.doClick();
				}
			}
		});
		userTF.setFont(new Font("Tahoma", Font.PLAIN, 14));
		userTF.setBounds(40, 85, 200, 40);
		contentPane.add(userTF);
		userTF.setColumns(10);
		
		passTF = new JPasswordField();
		passTF.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				char c = e.getKeyChar();
				if(c==KeyEvent.VK_ENTER) {
					confirmBtn.doClick();
				}
			}
		});
		passTF.setFont(new Font("Tahoma", Font.PLAIN, 14));
		passTF.setColumns(10);
		passTF.setBounds(40, 155, 200, 40);
		contentPane.add(passTF);
		
		JButton regisBtn = new JButton("Registrarse");
		regisBtn.setFont(new Font("Tahoma", Font.PLAIN, 13));
		regisBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				continuarRegis(e);
			}
		});
		regisBtn.setBounds(185, 240, 110, 30);
		regisBtn.setFocusable(false);
		contentPane.add(regisBtn);
		
		confirmBtn = new JButton("Confirmar");
		confirmBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				user = userTF.getText();
				String pass = passTF.getText();
				if(!user.isEmpty()&&!pass.isEmpty()) {
					//Conexion a la BD para leer datos
					String URL = "jdbc:mysql://localhost:3306/registroskas_bd";
					String USER = "root";
					String PASSW = "";
					try (Connection conn = DriverManager.getConnection(URL, USER, PASSW)){
						String SQL = "SELECT * FROM users WHERE user_n='"+user+"' AND user_psw='"+pass+"'"; //Se obtienen las fichas del user (segun si el user existe o no)
						PreparedStatement ps = cn.prepareStatement(SQL);
						ResultSet rs=ps.executeQuery();
						if(rs.next()) {
							//dispose();
							tarj = rs.getString("tarjeta");
							//JOptionPane.showMessageDialog(null, "Accediste correctamente a tu cuenta!");
							loged=true;
							int temp = main.totalFichas;
							//prepara la ventana main para actualizarse al iniciar sesion en una cuenta
							main.totalFichas = rs.getInt("fichasT"); //Leyendo los datos (solo las fichas)
							main.totalFichas+=temp;
							main.fichasLbl.setText("Cantidad de fichas: "+main.totalFichas);
							main.registerBtn.setVisible(false);
							main.registerBtn.setEnabled(false);
							main.logoutBtn.setEnabled(true);
							main.logoutBtn.setVisible(true);
							main.userLbl.setText("Sesion iniciada como: "+login.user);
							main.btnFichas.setEnabled(true);
							main.btnFichas.setToolTipText(null);
							regresarBtn(e);
						} else {
							JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrecto");
						}
						conn.close();
					} catch(Exception e1) {
						JOptionPane.showMessageDialog(null, "Error al iniciar sesion "+e1);
					}
				} else {
					JOptionPane.showMessageDialog(null, "Complete todos los campos");
				}
			}
		});
		confirmBtn.setFont(new Font("Tahoma", Font.PLAIN, 13));
		confirmBtn.setBounds(365, 310, 110, 30);
		confirmBtn.setFocusable(false);
		contentPane.add(confirmBtn);
		
		JButton regresarBtn = new JButton("Regresar");
		regresarBtn.setFont(new Font("Tahoma", Font.PLAIN, 13));
		regresarBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				regresarBtn(e);
			}
		});
		regresarBtn.setFocusable(false);
		regresarBtn.setBounds(10, 310, 110, 30);
		contentPane.add(regresarBtn);
		
		JLabel loginLbl = new JLabel("Iniciar sesion");
		loginLbl.setHorizontalAlignment(SwingConstants.CENTER);
		loginLbl.setFont(new Font("Tahoma", Font.PLAIN, 20));
		loginLbl.setBounds(0, 0, 486, 46);
		contentPane.add(loginLbl);
		
		JLabel lblNewLabel = new JLabel("No tienes una cuenta aún?");
		lblNewLabel.setBackground(new Color(10, 150, 75));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(0, 210, 486, 30);
		contentPane.add(lblNewLabel);
		
		JCheckBox verPswChk = new JCheckBox("Ver contraseña");
		verPswChk.setBackground(new Color(10, 150, 75));
		verPswChk.setFocusable(false);
		verPswChk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pass = passTF.getText();
				temp1.setText(pass);
				temp1.setFont(new Font("Tahoma", Font.PLAIN, 15));
				temp1.setColumns(10);
				temp1.setBounds(40, 155, 200, 37);
				temp1.setVisible(false);
				temp1.setEnabled(false);
				contentPane.add(temp1);
				//funcionalidad para ver el campo de la contraseña
				if(verPswChk.isSelected()) {
					temp1.setVisible(true);
					temp1.setEditable(true);
					temp1.setEnabled(true);

					passTF.setVisible(false);
					passTF.setEditable(false);
					passTF.setEnabled(false);
					temp1.addKeyListener(new KeyAdapter() {
						@Override
						public void keyReleased(KeyEvent e) {
							String temps1 = temp1.getText();
							passTF.setText(temps1);
						}
					});
				}else {
					temp1.setVisible(false);
					temp1.setEditable(false);
					temp1.setEnabled(false);
					String temps1 = temp1.getText();
					
					passTF.setText(temps1);
					passTF.setVisible(true);
					passTF.setEditable(true);
					passTF.setEnabled(true);
					passTF.addKeyListener(new KeyAdapter() {
						@Override
						public void keyReleased(KeyEvent e) {
							String pass = passTF.getText();
							temp1.setText(pass);

						}
					});
				}
			}
		});
		verPswChk.setBounds(40, 195, 120, 20);
		contentPane.add(verPswChk);
	}
}