import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;

public class register extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField userTF;
	private JPasswordField confirmPassTF;
	private boolean ready=false;
	
	private login l;
	private JPasswordField passTF;
	public void setlogin(login l) {
		this.l = l;
	}
	public void regresarBtn(java.awt.event.ActionEvent avt) {
		l.setVisible(true);
		this.setVisible(false);
	}
	

	/**
	 * Launch the application.
	 */
	/**
	 * Create the frame.
	 */
	public register() {
		setTitle("Registro de usuarios KaS");
		//setType(Type.UTILITY);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(10, 150, 75));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Registrarse");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 486, 46);
		contentPane.add(lblNewLabel);
		
		userTF = new JTextField();
		userTF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		userTF.setBounds(40, 85, 200, 40);
		contentPane.add(userTF);
		userTF.setColumns(10);
		
		JLabel userLbl = new JLabel("Nombre de usuario");
		userLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
		userLbl.setBounds(40, 60, 170, 30);
		contentPane.add(userLbl);
		
		JLabel passwLbl = new JLabel("Contraseña");
		passwLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
		passwLbl.setBounds(40, 130, 170, 30);
		
		contentPane.add(passwLbl);
		
		confirmPassTF = new JPasswordField();
		confirmPassTF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		confirmPassTF.setColumns(10);
		confirmPassTF.setBounds(40, 225, 200, 40);
		contentPane.add(confirmPassTF);
		
		JLabel lblVuelvaAIntroducir = new JLabel("Vuelva a introducir la contraseña");
		lblVuelvaAIntroducir.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblVuelvaAIntroducir.setBounds(40, 195, 226, 30);
		contentPane.add(lblVuelvaAIntroducir);
		
		JButton continuarBtn = new JButton("Continuar");
		continuarBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String usName = userTF.getText();
				String usPass = passTF.getText();
				String cPass = confirmPassTF.getText();
				if(usName.isEmpty()||usPass.isEmpty()||cPass.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Por favor rellena todos los campos");
				} else {
					if(usPass.equals(cPass) && ready==true) {
						guardarDB(usName, usPass);
						if(login.temp1.isVisible()) {
							login.temp1.setText(usPass);
						}
						login.userTF.setText(usName);
						login.passTF.setText(usPass);
						regresarBtn(e);
					}
				}
			}
		});
		continuarBtn.setFont(new Font("Tahoma", Font.PLAIN, 13));
		continuarBtn.setBounds(365, 310, 110, 30);
		continuarBtn.setFocusable(false);
		contentPane.add(continuarBtn);
		
		JLabel diffPLbl = new JLabel("Las contraseñas no son iguales");
		diffPLbl.setForeground(new Color(255, 0, 0));
		diffPLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		diffPLbl.setBounds(40, 260, 169, 36);
		diffPLbl.setVisible(false);
		contentPane.add(diffPLbl);
		
		JButton regresarBtn = new JButton("Regresar");
		regresarBtn.setFont(new Font("Tahoma", Font.PLAIN, 13));
		regresarBtn.setFocusable(false);
		regresarBtn.setBounds(10, 310, 110, 30);
		contentPane.add(regresarBtn);
		
		passTF = new JPasswordField();
		passTF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		passTF.setColumns(10);
		passTF.setBounds(40, 155, 200, 40);
		contentPane.add(passTF);
		
		JCheckBox verPswChk = new JCheckBox("Ver contraseñas");
		verPswChk.setBackground(new Color(10, 150, 75));
		verPswChk.setFocusable(false);
		verPswChk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pass1 = passTF.getText();
				String pass2 = confirmPassTF.getText();
				
				JTextField temp1 = new JTextField(pass1);
				temp1.setFont(new Font("Tahoma", Font.PLAIN, 15));
				temp1.setColumns(10);
				temp1.setBounds(40, 155, 200, 37);
				temp1.setVisible(false);
				temp1.setEnabled(false);
				contentPane.add(temp1);
				
				JTextField temp2 = new JTextField(pass2);
				temp2.setFont(new Font("Tahoma", Font.PLAIN, 15));
				temp2.setColumns(10);
				temp2.setBounds(40, 225, 200, 37);
				temp2.setVisible(false);
				temp2.setEnabled(false);
				contentPane.add(temp2);
				
				if(verPswChk.isSelected()) {
					temp1.setVisible(true);
					temp2.setVisible(true);
					
					temp1.setEditable(true);
					temp2.setEditable(true);
					
					temp1.setEnabled(true);
					temp2.setEnabled(true);
					
					passTF.setVisible(false);
					passTF.setEditable(false);
					passTF.setEnabled(false);
					
					confirmPassTF.setVisible(false);
					confirmPassTF.setEditable(false);
					confirmPassTF.setEnabled(false);
					
					temp1.addKeyListener(new KeyAdapter() {
						@Override
						public void keyReleased(KeyEvent e) {
							String temps1 = temp1.getText();
							String temps2 = temp2.getText();
							passTF.setText(temps1);
							confirmPassTF.setText(temps2);
							
							if(!passTF.getText().equals(confirmPassTF.getText()) || !passTF.getText().equals(temps1) || !passTF.getText().equals(temps2)) {
								diffPLbl.setVisible(true);
								ready=false;
							} else {
								diffPLbl.setVisible(false);
								ready=true;
							}
						}
					});
					temp2.addKeyListener(new KeyAdapter() {
						@Override
						public void keyReleased(KeyEvent e) {
							String temps1 = temp1.getText();
							String temps2 = temp2.getText();
							passTF.setText(temps1);
							confirmPassTF.setText(temps2);
							
							if(!passTF.getText().equals(confirmPassTF.getText()) || !passTF.getText().equals(temps1) || !passTF.getText().equals(temps2)) {
								diffPLbl.setVisible(true);
								ready=false;
							} else {
								diffPLbl.setVisible(false);
								ready=true;
							}
						}
					});
					
				} else {
					
					temp1.setVisible(false);
					temp1.setEditable(false);
					temp1.setEnabled(false);
					
					temp2.setVisible(false);
					temp2.setEditable(false);
					temp2.setEnabled(false);
					
					temp1.setText(pass1);
					temp2.setText(pass2);
					
					passTF.setVisible(true);
					passTF.setEditable(true);
					passTF.setEnabled(true);
					
					confirmPassTF.setVisible(true);
					confirmPassTF.setEditable(true);
					confirmPassTF.setEnabled(true);
					
					temp1.addKeyListener(new KeyAdapter() {
						@Override
						public void keyReleased(KeyEvent e) {
							String temps1 = temp1.getText();
							String temps2 = temp2.getText();
							passTF.setText(temps1);
							confirmPassTF.setText(temps2);
						}
					});
					temp2.addKeyListener(new KeyAdapter() {
						@Override
						public void keyReleased(KeyEvent e) {
							String temps1 = temp1.getText();
							String temps2 = temp2.getText();
							passTF.setText(temps1);
							confirmPassTF.setText(temps2);
						}
					});
				}
			}
		});
		verPswChk.setBounds(120, 135, 120, 20);
		contentPane.add(verPswChk);
		
		regresarBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				regresarBtn(e);
			}
		});
		
		confirmPassTF.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String usPass = passTF.getText();
				String cPass = confirmPassTF.getText();
				if(!usPass.equals(cPass)&&!usPass.equals("")) {
					diffPLbl.setVisible(true);
					ready=false;
				} else {
					diffPLbl.setVisible(false);
					ready=true;
				}
				
				char c = e.getKeyChar();
				if(c==KeyEvent.VK_ENTER) {
					continuarBtn.doClick();
				}
				
			}
		});
		
		passTF.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String usPass = passTF.getText();
				String cPass = confirmPassTF.getText();
				if(!usPass.equals(cPass)&&!cPass.equals("")) {
					diffPLbl.setVisible(true);
					ready=false;
				} else {
					diffPLbl.setVisible(false);
					ready=true;
				}
				
				char c = e.getKeyChar();
				if(c==KeyEvent.VK_ENTER) {
					continuarBtn.doClick();
				}
				
			}
		});
	}
	
	private void guardarDB(String us, String passw) {
		String URL = "jdbc:mysql://localhost:3306/registroskas_bd";
		String USER = "root";
		String PASSW = "";
		try (Connection conn = DriverManager.getConnection(URL, USER, PASSW)){
			String SQL = "INSERT INTO users(user_n, user_psw, fichasT, tarjeta, fichas_compradas, total_comprado) VALUES(?,?,?,?,?,?)";
			try(PreparedStatement stmt = conn.prepareStatement(SQL)) {
				stmt.setString(1, us);
				stmt.setString(2, passw);
				stmt.setInt(3, main.totalFichas);
				stmt.setString(4, "");
				stmt.setInt(5, 0);
				stmt.setInt(6, 0);
				
				stmt.executeUpdate();
				JOptionPane.showMessageDialog(null, "Usuario registrado correctamente!");
			}
			conn.close();
		} catch(SQLException e) {
			JOptionPane.showMessageDialog(null, "Error al guardar los datos: "+e);
		}
	}
}
