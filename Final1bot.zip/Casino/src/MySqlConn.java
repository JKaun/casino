import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class MySqlConn {
	Connection cn;
	public Connection conexion() {
		String URL = "jdbc:mysql://localhost:3306/registroskas_bd";
		String USER = "root";
		String PASSW = "";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			cn = (Connection) DriverManager.getConnection(URL,USER,PASSW);
		} catch (Exception e) {
			//JOptionPane.showMessageDialog(null, "Error: "+e, "Error", JOptionPane.ERROR_MESSAGE);
		}
		return cn;
		
	}
	
}
