import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class BlackJack extends JFrame{
	
	
	public main m;
	public void setmain(main m) {
		this.m = null;
	}
	
	
	private boolean playerWin;
	public void regresarBtn(java.awt.event.ActionEvent avt) {
		main m = new main();
		m.main(null);
		frame.setVisible(false);
		this.setVisible(false);
	}
    private class Card {
        String value;
        String type;
        
        
        Card(String value, String type) {
            this.value = value;
            this.type = type;
        }

        public String toString() {
            return value + "-" + type;
        }

        public int getValue() {
            if ("AJQK".contains(value)) { //A J Q K
                if (value == "A") {
                    return 11;
                }
                return 10;
            }
            return Integer.parseInt(value); //2-10
        }

        public boolean isAce() {
            return value == "A";
        }

        public String getImagePath() {
            return "./cards/" + toString() + ".png";
        }
    }

    ArrayList<Card> deck;
    Random random = new Random(); //Barajear

    //dealer
    Card hiddenCard;
    ArrayList<Card> dealerHand;
    int dealerSum;
    int dealerAceCount;

    //player
    ArrayList<Card> playerHand;
    int playerSum;
    int playerAceCount;

    //window
    int boardWidth = 750;
    int boardHeight = 600;

    int cardWidth = 110; //En una proporcion de 1/1.4
    int cardHeight = 154;
    
    //Fichas a apostar
    private int fichas=0;
    JSpinner spinner = new JSpinner();

    JButton regresarBtn = new JButton("Regresar");
    
    
    Image hiddenCardImg;
    JFrame frame = new JFrame("Black Jack - KaS");
    JPanel gamePanel = new JPanel() {
    	
        @Override
        public void paintComponent(Graphics g) {
        	super.paintComponents(g);
            try {
                //Dibujar la carta oculta
                hiddenCardImg = new ImageIcon(getClass().getResource("./cards/BACK.png")).getImage();
                if (!quedarseBtn.isEnabled()&&!regresarBtn.isEnabled()) {
                    hiddenCardImg = new ImageIcon(getClass().getResource(hiddenCard.getImagePath())).getImage();
                }
                g.drawImage(hiddenCardImg, 20, 20, cardWidth, cardHeight, null);

                //Dibujar la mano del dealer
                for (int i = 0; i < dealerHand.size(); i++) {
                    Card card = dealerHand.get(i);
                    Image cardImg = new ImageIcon(getClass().getResource(card.getImagePath())).getImage();
                    g.drawImage(cardImg, cardWidth + 25 + (cardWidth + 5)*i, 20, cardWidth, cardHeight, null);
                }

                //Dibujar la mano del jugador
                for (int i = 0; i < playerHand.size(); i++) {
                    Card card = playerHand.get(i);
                    Image cardImg = new ImageIcon(getClass().getResource(card.getImagePath())).getImage();
                    g.drawImage(cardImg, 20 + (cardWidth + 5)*i, 320, cardWidth, cardHeight, null);
                }
                buttonPanel.add(spinner);

                initBtn.setEnabled(false);
                spinner.addChangeListener(new ChangeListener() {
                	public void stateChanged(ChangeEvent e) {
                			if((Integer)spinner.getValue()!=0) {
                				initBtn.setEnabled(true);
                			} else {
                				initBtn.setEnabled(false);
                			}
                	}
                });

                spinner.addKeyListener(new KeyAdapter() {
                	@Override
                	public void keyTyped(KeyEvent e) {
                		if((Integer)spinner.getValue()!=0) {
                			initBtn.setEnabled(true);
                		} else {
                			initBtn.setEnabled(false);
                		}
                	}
                });
                
                
                if (!quedarseBtn.isEnabled()&&!regresarBtn.isEnabled()) {
                	fichas=(Integer)spinner.getValue();
                	dealerSum = reduceDealerAce();
                    playerSum = reducePlayerAce();
//                    System.out.println("Plantado: ");
//                    System.out.println(dealerSum);
//                    System.out.println(playerSum);

                    String message = "";
                    if (playerSum > 21) {
                        message = "Perdiste!";
                        playerWin=false;
                        main.totalFichas-=fichas;
                    //	JOptionPane.showMessageDialog(null,"Perdiste "+fichas+" fichas","Mala suerte!",JOptionPane.INFORMATION_MESSAGE);
                    }
                    else if (dealerSum > 21) {
                        message = "Ganaste!";
                        playerWin=true;
                        main.totalFichas+=fichas;
                    	//JOptionPane.showMessageDialog(null,"Ganaste "+fichas+" fichas","Felicidades!",JOptionPane.INFORMATION_MESSAGE);
                    }
                    //Both <= 21
                    else if (playerSum == dealerSum) {
                        message = "Empate!";
                        
                    }
                    else if (playerSum > dealerSum) {
                        message = "Ganaste!";
                        playerWin=true;
                        main.totalFichas+=fichas;
                    	//JOptionPane.showMessageDialog(null,"Ganaste "+fichas+" fichas","Felicidades!",JOptionPane.INFORMATION_MESSAGE);
                    }
                    else if (playerSum < dealerSum) {
                        message = "Perdiste!";
                        playerWin=false;
                        main.totalFichas=main.totalFichas-=fichas;
                    	//JOptionPane.showMessageDialog(null,"Perdiste "+fichas+" fichas","Mala suerte!",JOptionPane.INFORMATION_MESSAGE);
                        
                    }
                   

                    g.setFont(new Font("Arial", Font.PLAIN, 30));
                    g.setColor(Color.white);
                    g.drawString(message, (boardWidth/2)-100, 220);
                    g.drawString("Tus cartas: "+playerSum, (boardWidth/2)-100, 250);
                    g.drawString("Dealer cartas: "+dealerSum, (boardWidth/2)-100, 275);
                    if(message.equals("Ganaste!")) {
                    	g.drawString("Ganaste "+fichas+" fichas", (boardWidth/2)-100, 305);
                    } else if(message.equals("Perdiste!")) {
                    	g.drawString("Perdiste "+fichas+" fichas", (boardWidth/2)-100, 305);
                    }
                    spinner.setValue(0);
                    spinner.setEnabled(true);
                    spinner.setModel(new SpinnerNumberModel(0, 0, main.totalFichas, 10));
                    initBtn.setEnabled(false);
                    regresarBtn.setEnabled(true);
                    fichasLbl.setText("Fichas restantes: "+main.totalFichas);
                    
                    
//                    if(playerWin==true) {
//                		System.out.println("HOLA");
//                    } else if(playerWin==false){
//                    	System.out.println("ADIOS");
//                    }
                }
            } catch (Exception e) {
               e.printStackTrace();
           }
        }
    };
//    public void paint(Graphics g) {
//    	super.paint(g);
//    	try {
//   	 g.drawImage(hiddenCardImg, 20, 20, cardWidth, cardHeight, null);
//   	 g.drawImage(hiddenCardImg, cardWidth + 25 + (cardWidth + 5), 20, cardWidth, cardHeight, null);
//   	 g.drawImage(hiddenCardImg, 20 + (cardWidth + 5), 320, cardWidth, cardHeight, null);
//   	 g.drawImage(hiddenCardImg, 20 + (cardWidth + 5)*2, 320, cardWidth, cardHeight, null);
//    	} catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
    
    
    JPanel buttonPanel = new JPanel();
    JButton pedirBtn = new JButton("Pedir");
    JButton quedarseBtn = new JButton("Quedarse");
    JButton initBtn = new JButton("Comenzar");
    JLabel fichasLbl = new JLabel(main.totalFichas+" fichas restantes");


    BlackJack() {
    	startGame();
        frame.setVisible(true);
        frame.setSize(boardWidth, boardHeight);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gamePanel.setBackground(new Color(0, 128, 64));
        frame.getContentPane().add(gamePanel);
        gamePanel.setLayout(null);
        fichasLbl.setHorizontalAlignment(SwingConstants.RIGHT);
        buttonPanel.add(fichasLbl);
        regresarBtn.setFocusable(false);
        buttonPanel.add(regresarBtn);
        
        pedirBtn.setFocusable(false);
        buttonPanel.add(pedirBtn);
        quedarseBtn.setFocusable(false);
        buttonPanel.add(quedarseBtn);
        frame.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        
        initBtn.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {

        		//super.paintComponent(g);
        		startGame();
        		spinner.setEnabled(false);
        		pedirBtn.setEnabled(true);
        		quedarseBtn.setEnabled(true);
        		regresarBtn.setEnabled(false);
        	}
        });
        
               
        initBtn.setFocusable(false);
        
        buttonPanel.add(initBtn);
        spinner.setModel(new SpinnerNumberModel(0, 0, main.totalFichas, 100));
        
        buttonPanel.add(spinner);
        regresarBtn.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		regresarBtn(e);
        	}
        });
        
        pedirBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Card card = deck.remove(deck.size()-1);
                playerSum += card.getValue();
                playerAceCount += card.isAce() ? 1 : 0;
                playerHand.add(card);
                if (reducePlayerAce() > 21) { //A + 2 + J --> 1 + 2 + J
                	quedarseBtn.setEnabled(false);
                    pedirBtn.setEnabled(false); 
                } if(playerSum==21) {
                	quedarseBtn.setEnabled(false);
                	pedirBtn.setEnabled(false);
                } else if(playerSum>21) {
                	quedarseBtn.setEnabled(false);
                	pedirBtn.setEnabled(false);
                }
                gamePanel.repaint();
            }
        });

        quedarseBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pedirBtn.setEnabled(false);
                quedarseBtn.setEnabled(false);

                while (dealerSum < 17) {
                    Card card = deck.remove(deck.size()-1);
                    dealerSum += card.getValue();
                    dealerAceCount += card.isAce() ? 1 : 0;
                    dealerHand.add(card);
                }
                gamePanel.repaint();
                
            }
        });

        gamePanel.repaint();
    }

    public void startGame() {
    	
    	 gamePanel.repaint();
    	 quedarseBtn.setEnabled(false);
    	 pedirBtn.setEnabled(false);
    	 
        //Deck
        buildDeck();
        shuffleDeck();

        //Dealer
        dealerHand = new ArrayList<Card>();
        dealerSum = 0;
        dealerAceCount = 0;

        hiddenCard = deck.remove(deck.size()-1); //Quitar la ultima carta
        dealerSum += hiddenCard.getValue();
        dealerAceCount += hiddenCard.isAce() ? 1 : 0;

        Card card = deck.remove(deck.size()-1);
        dealerSum += card.getValue();
        dealerAceCount += card.isAce() ? 1 : 0;
        dealerHand.add(card);
//
//        System.out.println("Dealer:");
//        System.out.println(hiddenCard);
//        System.out.println(dealerHand);
//        System.out.println(dealerSum);
//        System.out.println(dealerAceCount);


        //player
        playerHand = new ArrayList<Card>();
        playerSum = 0;
        playerAceCount = 0;

        for (int i = 0; i < 2; i++) {
            card = deck.remove(deck.size()-1);
            playerSum += card.getValue();
            playerAceCount += card.isAce() ? 1 : 0;
            playerHand.add(card);
        }
        if(playerSum==21&&fichas!=0) {
    		quedarseBtn.setEnabled(false);
    		regresarBtn.setEnabled(false);
    	}
//        System.out.println("Jugador: ");
//        System.out.println(playerHand);
//        System.out.println(playerSum);
//        System.out.println(playerAceCount);
        
    }

    public void buildDeck() {
        deck = new ArrayList<Card>();
        String[] values = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        String[] types = {"C", "D", "H", "S"};

        for (int i = 0; i < types.length; i++) {
            for (int j = 0; j < values.length; j++) {
                Card card = new Card(values[j], types[i]);
                deck.add(card);
            }
        }

//        System.out.println("Deck base:");
//        System.out.println(deck);
    }

    public void shuffleDeck() {
        for (int i = 0; i < deck.size(); i++) {
            int j = random.nextInt(deck.size());
            Card currCard = deck.get(i);
            Card randomCard = deck.get(j);
            deck.set(i, randomCard);
            deck.set(j, currCard);
        }

//        System.out.println("Despues de barajear");
//        System.out.println(deck);
    }

    public int reducePlayerAce() {
        while (playerSum > 21 && playerAceCount > 0) {
            playerSum -= 10;
            playerAceCount -= 1;
        }
        return playerSum;
    }

    public int reduceDealerAce() {
        while (dealerSum > 21 && dealerAceCount > 0) {
            dealerSum -= 10;
            dealerAceCount -= 1;
        }
        return dealerSum;
    }
}