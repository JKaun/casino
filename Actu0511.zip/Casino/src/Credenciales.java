import java.util.HashMap;

public class Credenciales {

		HashMap<String,String> LoginInfo = new HashMap<String,String>();
		
		Credenciales(){
			
			LoginInfo.put("Kaun8","3302");
			LoginInfo.put("Caife2","PASSWORD");
		}
		
		public HashMap<String, String> getLoginInfo(){
			return LoginInfo;
		}
	
}
