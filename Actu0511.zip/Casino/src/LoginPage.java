import java.awt.Color;
import java.awt.EventQueue;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginPage extends JFrame {
	
	HashMap <String, String> LoginInfo = new HashMap<String, String>();
	
	LoginPage(HashMap<String, String>Original) {
		LoginInfo = Original;
	}

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPage frame = new LoginPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginPage() {
		
		setResizable(false);
		setTitle("Casino KaS");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 64));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Usuario:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setBounds(66, 48, 76, 30);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField("Kaun8");
		textField.setBounds(183, 52, 144, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(183, 111, 144, 30);
		contentPane.add(passwordField);
		
		JLabel lblContrasea = new JLabel("Contraseña:");
		lblContrasea.setHorizontalAlignment(SwingConstants.LEFT);
		lblContrasea.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblContrasea.setBounds(66, 107, 133, 30);
		contentPane.add(lblContrasea);
		
		JButton btnConfirmar = new JButton("Confirmar");
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String usuarioID = textField.getText();
				String password = String.valueOf(passwordField.getPassword());
				
				if(LoginInfo.containsKey(usuarioID)&&LoginInfo.get(usuarioID).equals(password)) {
					//if(LoginInfo.get(usuarioID).equals(password)) {
						System.out.println("Login successful");
					//}
					//else {
						//System.out.print("Wrong password");
					//}

				}
				else {
					System.out.println("uHOlad");
				}
					
			}
		});
		btnConfirmar.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnConfirmar.setBounds(373, 320, 101, 30);
		contentPane.add(btnConfirmar);
		btnConfirmar.setFocusable(false);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setState(JFrame.ICONIFIED);
				fichasP fichasP = new fichasP();
				fichasP.setVisible(true);
			}
		});
		btnRegresar.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnRegresar.setFocusable(false);
		btnRegresar.setBounds(10, 320, 101, 30);
		contentPane.add(btnRegresar);
		
	
		
		
		
		
	}
}
